<?php

include("dp.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize response array
$response = array();

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from form-data
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $case_study_id = isset($_POST['case_study_id']) ? intval($_POST['case_study_id']) : 0;
    $question_answers = isset($_POST['question_answers']) ? $_POST['question_answers'] : '';

    // Convert JSON string to PHP array
    $question_answers_array = json_decode($question_answers, true);

    // Check if the user already exists in the user_answers table
    $existingUserSql = "SELECT * FROM user_answers WHERE user_id = $user_id AND case_study_id = $case_study_id";
    $existingUserResult = $conn->query($existingUserSql);

    if ($existingUserResult->num_rows > 0) {
        // User already exists, show alert message
        $response['status'] = 'error';
        $response['message'] = 'User already exists in the database. No new data submitted.';
    } else {
        // User does not exist, insert new records
        foreach ($question_answers_array as $answer) {
            $question_id = $answer['question_id'];
            $user_answer = $answer['user_answer'];

            // Fetch correct_answer for the given question_id and case_study_id from sub_questions
            $fetchCorrectAnswerQuery = "SELECT correct_answer FROM sub_questions WHERE question_id = $question_id AND case_study_id = $case_study_id";
            $correctAnswerResult = $conn->query($fetchCorrectAnswerQuery);

            if ($correctAnswerResult && $correctAnswerResult->num_rows > 0) {
                $row = $correctAnswerResult->fetch_assoc();
                $correct_answer = $row['correct_answer'];

                // Check if user's answer matches the correct_answer
                $Correct = ($user_answer === $correct_answer) ? 1 : 0;
                $Wrong = ($user_answer !== $correct_answer) ? 1 : 0;

                // Insert data into user_answers table
                $insertSql = "INSERT INTO user_answers (user_id, case_study_id, question_id, user_answer, Correct, Wrong)
                VALUES ('$user_id', '$case_study_id', '$question_id', '$user_answer', $Correct, $Wrong)";

                if ($conn->query($insertSql) === TRUE) {
                    $response['status'] = 'success';
                    $response['message'] = 'Records inserted successfully';
                } else {
                    $response['status'] = 'error';
                    $response['message'] = 'Error inserting record: ' . $conn->error;
                }
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Error: No matching question found in sub_questions table for the given question_id and case_study_id.';
            }
        }
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method. This endpoint only accepts POST requests.';
}

// Close connection
$conn->close();

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
