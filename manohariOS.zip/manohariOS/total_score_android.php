<?php
// Assuming you have a database connection
require_once('dp.php');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from POST data
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Calculate total score and total wrong answers
    $query = "SELECT SUM(Correct) AS total_correct, SUM(Wrong) AS total_wrong, COUNT(*) AS total_attended FROM user_answers WHERE user_id = $user_id";
    $result = $conn->query($query);

    $response = array();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Store the totals in the totalscore table
        $total_correct = (double)$row['total_correct'];
        $total_wrong = (double)$row['total_wrong'];
        $total_attended = (double)$row['total_attended'];

        // Check if user_id exists in totalscore table
        $check_query = "SELECT user_id FROM totalscore WHERE user_id = $user_id";
        $check_result = $conn->query($check_query);

        if ($check_result->num_rows > 0) {
            // Update the existing record
            $update_query = "UPDATE totalscore SET total_score = ?, total_wrong = ? WHERE user_id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param("ddd", $total_correct, $total_wrong, $user_id);
        } else {
            // Insert a new record
            $insert_query = "INSERT INTO totalscore (user_id, total_score, total_wrong) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($insert_query);
            $stmt->bind_param("ddd", $user_id, $total_correct, $total_wrong);
        }

        if ($stmt->execute()) {
            $response['status'] = 'success';
            // Set the total score, total wrong, and total question in the response
            $response['total_score'] = $total_correct;
            $response['total_wrong'] = $total_wrong;
            $response['total_question'] = $total_attended;
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error: ' . $stmt->error;
        }

        $stmt->close();
    } else {
        $response['status'] = 'error';
        $response['message'] = 'No data found for the user.';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'User ID not provided.';
}

// Close the connection
$conn->close();

// Output the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
