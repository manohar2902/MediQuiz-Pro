<?php
// Include the database connection configuration
include("dp.php");

// Set up error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming raw data format is sent in the POST body
    $raw_data = file_get_contents("php://input");
    $addQuestionsRequest = json_decode($raw_data);

    if ($addQuestionsRequest !== null) {
        // Extract data from the request
        $caseStudyID = $addQuestionsRequest->caseStudyID;
        $questions = $addQuestionsRequest->questions;

        // Check if caseStudyID and questions are not empty
        if (!empty($caseStudyID) && !empty($questions)) {
            // Prepare the SQL statement
            $sql = "INSERT INTO sub_questions (case_study_id, question_id, question, option_1, option_2, option_3, option_4, correct_answer)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                // Loop through each question
                foreach ($questions as $question) {
                    // Extract data for the question
                    $question_id = $question->questionID;
                    $question_text = $question->question;
                    $option_1 = $question->option1;
                    $option_2 = $question->option2;
                    $option_3 = $question->option3;
                    $option_4 = isset($question->option4) ? $question->option4 : null;
                    $correct_answer = $question->correctAnswer;

                    // Check if any field is empty
                    if (empty($question_id) || empty($question_text) || empty($option_1) || empty($option_2) || empty($option_3) || empty($correct_answer)) {
                        $response['success'] = false;
                        $response['message'] = "All fields are required.";
                        break; // Break the loop on first empty field
                    }

                    // Bind parameters
                    $stmt->bind_param("iisssssi", $caseStudyID, $question_id, $question_text, $option_1, $option_2, $option_3, $option_4, $correct_answer);

                    // Execute the prepared statement
                    if ($stmt->execute()) {
                        $response['status'] = "success";
                        $response['message'] = "Data updated successfully";
                    } else {
                        $response['success'] = false;
                        $response['message'] = "Error: " . $conn->error;
                        break; // Break the loop on first error
                    }
                }
            } else {
                $response['success'] = false;
                $response['message'] = "Error in preparing the SQL statement: " . $conn->error;
            }

            // Close the statement
            $stmt->close();
        } else {
            $response['success'] = false;
            $response['message'] = "All fields are required.";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid data format.";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

// Close the database connection
$conn->close();

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
