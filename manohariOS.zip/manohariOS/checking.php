<?php
// Database connection details
require_once('dp.php');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user_id is sent via POST method
if(isset($_POST['user_id'])) {
    // User ID to check
    $user_id_to_check = $_POST['user_id'];

    // SQL query to check if the user ID exists in the database
    $sql = "SELECT user_id FROM user_answers WHERE user_id = $user_id_to_check";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User ID is present in the database
        $status = 1;
        $message = 'User ID is already in the database';
    } else {
        // User ID is not present in the database
        $status = 0;
        $message = 'User ID is not present in the database';
    }
} else {
    // If user_id is not sent via POST method
    $status = -1;
    $message = 'User ID is not provided via POST method';
}

// Close connection
$conn->close();

// Output response in JSON format
$response = array('status' => $status, 'message' => $message);
header('Content-Type: application/json');
echo json_encode($response);
?>
