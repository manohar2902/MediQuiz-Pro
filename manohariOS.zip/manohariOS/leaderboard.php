<?php
include 'dp.php';

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to select user_id and other columns from the table, ordered by Correct in descending order
$sql = "SELECT user_id, total_score FROM totalscore ORDER BY total_score DESC";

// Execute the query
$result = $conn->query($sql);

// Check if there are rows in the result set
if ($result->num_rows > 0) {
    // Create an array to store the results
    $data = array();

    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        // Add each row to the data array
        $data[] = $row;
    }

    // Output the data in JSON format
    echo json_encode($data);
} else {
    echo json_encode(array("message" => "No results found"));
}

// Close the database connection
$conn->close();
?>
