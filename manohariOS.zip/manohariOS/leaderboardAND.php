<?php
include 'dp.php';

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define the URL prefix
$url_prefix = "http://172.20.10.8/manohariOS/";

// SQL query to select user_id and total_score from totalscore table, ordered by total_score in descending order
$sql_total_score = "SELECT user_id, total_score FROM totalscore ORDER BY total_score DESC";

// Execute the query to fetch total scores
$result_total_score = $conn->query($sql_total_score);

// Check if there are rows in the total score result set
if ($result_total_score->num_rows > 0) {
    // Create an array to store the results
    $data = array();

    // Output data of each row
    while ($row_total_score = $result_total_score->fetch_assoc()) {
        // Add each row to the data array
        $data[] = $row_total_score;
    }

    // SQL query to select rank_image from rank table
    $sql_rank_image = "SELECT rank_image FROM rank";

    // Execute the query to fetch rank images
    $result_rank_image = $conn->query($sql_rank_image);

    // Check if there are rows in the rank image result set
    if ($result_rank_image->num_rows > 0) {
        // Fetch the rank images from the result set
        $rank_images = array();
        while ($row_rank_image = $result_rank_image->fetch_assoc()) {
            $rank_images[] = $url_prefix . $row_rank_image['rank_image'];
        }

        // Initialize rank counter
        $rank = 1;

        // Assign ranks and associate them with rank images
        foreach ($data as &$row) {
            // If there are rank images left and rank is less than or equal to 3, assign them to each entry
            if (!empty($rank_images) && $rank <= 3) {
                // Calculate the index for rank image
                $index = ($rank - 1) % count($rank_images);
                // Assign the rank image
                $row['rank_image'] = $rank_images[$index];
            } else {
                // If no rank images left or rank is greater than 3, assign an empty string
                $row['rank_image'] = '';
            }
            // Assign the rank
            $row['rank'] = $rank;
            // Increment rank counter
            $rank++;
        }
    } else {
        // If no rank images found, assign empty strings to all entries
        foreach ($data as &$row) {
            $row['rank_image'] = '';
            // Assign rank as empty string
            $row['rank'] = '';
        }
    }

    // Output the data in JSON format with 'data' key
    echo json_encode(array('data' => $data));
} else {
    // Output JSON object with a message if no total score results found
    echo json_encode(array("data" => array(), "message" => "No total score results found"));
}

// Close the database connection
$conn->close();
?>
