<?php
// Define the base URL for constructing full URLs
$baseUrl = "http://172.20.10.8/manohariOS/";

// Include database connection
include 'dp.php';

$user_id = $_GET['user_id'];

$loginqry = "SELECT * FROM profile WHERE user_id = '$user_id'";
$qry = mysqli_query($conn, $loginqry);

$response = array();

if (mysqli_num_rows($qry) > 0) {
    $userObj = mysqli_fetch_assoc($qry);

    // Constructing the profile photo URL
    $profile_photo_url = $baseUrl . $userObj['profile_photo'];

    $userObj['profile_photo'] = $profile_photo_url;

    $response['status'] = true;
    $response['message'] = "Login Successfully";
    $response['data'] = $userObj;
} else {
    $response['status'] = false;
    $response['message'] = "Login Failed";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
