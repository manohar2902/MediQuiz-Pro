<?php
// Assuming you have a database connection
include 'dp.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from POST data
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Retrieve total_score and total_wrong for the user
    $query = "SELECT total_score, total_wrong FROM totalscore WHERE user_id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($total_score, $total_wrong);
    
    $response = array();

    if ($stmt->fetch()) {
        $response['status'] = 'success';
        $response['total_score'] = $total_score;
        $response['total_wrong'] = $total_wrong;
    } else {
        $response['status'] = 'error';
        $response['message'] = 'No data found for the user.';
    }

    $stmt->close();
} else {
    $response['status'] = 'error';
    $response['message'] = 'User ID not provided.';
}

// Close the connection
$conn->close();

// Output the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
