<?php
// Assuming you have a database connection
require_once('dp.php');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from POST data
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Calculate total score and total wrong answers
    $query = "SELECT SUM(Correct) AS total_score, SUM(Wrong) AS total_wrong FROM user_answers WHERE user_id = $user_id";
    $result = $conn->query($query);

    $response = array();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Store the totals in the totalscore table
        $total_score = $row['total_score'];
        $total_wrong = $row['total_wrong'];

        // Check if user_id exists in totalscore table
        $check_query = "SELECT user_id FROM totalscore WHERE user_id = $user_id";
        $check_result = $conn->query($check_query);

        if ($check_result->num_rows > 0) {
            // Update the existing record
            $update_query = "UPDATE totalscore SET total_score = ?, total_wrong = ? WHERE user_id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param("iii", $total_score, $total_wrong, $user_id);
        } else {
            // Insert a new record
            $insert_query = "INSERT INTO totalscore (user_id, total_score, total_wrong) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($insert_query);
            $stmt->bind_param("iii", $user_id, $total_score, $total_wrong);
        }

        if ($stmt->execute()) {
            $response['status'] = 'success';
            $response['message'] = 'Total score and total wrong answers stored successfully.';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error: ' . $stmt->error;
        }

        $stmt->close();
    } else {
        $response['status'] = 'error';
        $response['message'] = 'No data found for the user.';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'User ID not provided.';
}

// Close the connection
$conn->close();

// Output the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
