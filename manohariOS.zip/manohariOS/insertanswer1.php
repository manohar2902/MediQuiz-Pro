<?php

require_once('dp.php');

// Initialize response array
$response = array();

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming raw JSON data is sent in the request body
    $raw_data = file_get_contents("php://input");
    $requestData = json_decode($raw_data, true);

    // Check if JSON decoding was successful
    if ($requestData !== null) {
        // Get user_id and case_study_id from the JSON data
        $user_id = isset($requestData['user_id']) ? intval($requestData['user_id']) : 0;
        $case_study_id = isset($requestData['case_study_id']) ? intval($requestData['case_study_id']) : 0;

        // Check if the user already exists in the database
        $existingRowSql = "SELECT * FROM user_answers WHERE user_id = $user_id AND case_study_id = $case_study_id";
        $existingRowResult = $conn->query($existingRowSql);

        if ($existingRowResult->num_rows > 0) {
            // User already exists in the database
            $response['status'] = 'error';
            $response['message'] = 'User already exists in the database. No new data submitted.';
            echo json_encode($response);
            exit; // Stop further execution
        } else {
            // User does not exist, continue processing the submitted data
            // Initialize arrays to store data for batch insert and update
            $insertValues = [];
            $updateValues = [];

            // Loop through the question_answers array
            if (isset($requestData['question_answers']) && is_array($requestData['question_answers'])) {
                foreach ($requestData['question_answers'] as $question_answer) {
                    // Get data for each question
                    $question_id = isset($question_answer["question_id"]) ? intval($question_answer["question_id"]) : 0;
                    $user_answer = isset($question_answer["user_answer"]) ? mysqli_real_escape_string($conn, $question_answer["user_answer"]) : '';

                    // Fetch correct_answer for the given question_id and case_study_id from sub_questions
                    $fetchCorrectAnswerQuery = "SELECT correct_answer FROM sub_questions WHERE question_id = $question_id AND case_study_id = $case_study_id";
                    $correctAnswerResult = $conn->query($fetchCorrectAnswerQuery);

                    if ($correctAnswerResult && $correctAnswerResult->num_rows > 0) {
                        $row = $correctAnswerResult->fetch_assoc();
                        $correct_answer = $row['correct_answer'];

                        // Check if user's answer matches the correct_answer
                        $Correct = ($user_answer === $correct_answer) ? 1 : 0;
                        $Wrong = ($user_answer !== $correct_answer) ? 1 : 0;

                        // Add values to the batch insert array
                        $insertValues[] = "($user_id, $case_study_id, $question_id, '$user_answer', $Correct, $Wrong)";
                    } else {
                        $response['status'] = 'error';
                        $response['message'] = 'No matching question found in sub_questions table for the given question_id and case_study_id.';
                        echo json_encode($response);
                        exit; // Stop further execution
                    }
                }
            } else {
                $response['status'] = 'error';
                $response['message'] = 'No question_answers array found in the submitted data.';
                echo json_encode($response);
                exit; // Stop further execution
            }

            if (!empty($insertValues)) {
                // Prepare and execute the batch INSERT query
                $insertQuery = "INSERT INTO user_answers (user_id, case_study_id, question_id, user_answer, Correct, Wrong) VALUES " . implode(", ", $insertValues);

                if ($conn->query($insertQuery) === TRUE) {
                    $response['status'] = 'success';
                    $response['message'] = 'Records inserted successfully';
                } else {
                    $response['status'] = 'error';
                    $response['message'] = 'Error: ' . $insertQuery . '<br>' . $conn->error;
                }
            }

            if (!empty($updateValues)) {
                // Execute the batch UPDATE queries
                foreach ($updateValues as $updateQuery) {
                    if ($conn->query($updateQuery) !== TRUE) {
                        $response['status'] = 'error';
                        $response['message'] = 'Error updating records: ' . $updateQuery . '<br>' . $conn->error;
                        echo json_encode($response);
                        exit; // Stop further execution
                    }
                }
            }
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Invalid JSON data.';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method. This endpoint only accepts POST requests.';
}

// Close the database connection
$conn->close();

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);

?>
