//
//  studentlistmodel.swift
//  MediquizPro
//
//  Created by SAIL on 09/12/23.
//

import Foundation

struct WelcomeElement: Codable {
    let userID, totalScore: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case totalScore = "total_score"
    }
}

typealias studentlistmodel = [WelcomeElement]
