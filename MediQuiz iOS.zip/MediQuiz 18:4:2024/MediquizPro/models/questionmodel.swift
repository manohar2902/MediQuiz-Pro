//
//  questionmodel.swift
//  MediquizPro
//
//  Created by SAIL on 02/11/23.
//

import Foundation

// MARK: - Welcome
struct questionmodel: Codable {
    let status: String
    let questions: [WelcomeQuestion]
}

// MARK: - WelcomeQuestion
struct WelcomeQuestion: Codable {
    let id, caseStudy: String
    let photo: String
    let questions: [QuestionQuestion]

    enum CodingKeys: String, CodingKey {
        case id
        case caseStudy = "Case_Study"
        case photo, questions
    }
}

// MARK: - QuestionQuestion
struct QuestionQuestion: Codable {
    let text: String
    let options: Options
    let correctAnswer: String

    enum CodingKeys: String, CodingKey {
        case text, options
        case correctAnswer = "correct_answer"
    }
}

// MARK: - Options
struct Options: Codable {
    let option1, option2, option3, option4: String

    enum CodingKeys: String, CodingKey {
        case option1 = "option_1"
        case option2 = "option_2"
        case option3 = "option_3"
        case option4 = "option_4"
    }
}



