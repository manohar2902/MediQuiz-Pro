//
//  leaderboardmodel.swift
//  MediquizPro
//
//  Created by SAIL L1 on 12/12/23.
//

import Foundation

// MARK: - WelcomeElement


struct leaderboardmodel: Codable {
    let userID, totalScore: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case totalScore = "total_score"
    }
}

typealias Welcome = [leaderboardmodel]
