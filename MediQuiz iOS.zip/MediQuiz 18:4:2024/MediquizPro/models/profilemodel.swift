//
//  profilemodel.swift
//  MediquizPro
//
//  Created by SAIL on 27/10/23.
//

import Foundation
// MARK: - Welcome
struct profilemodel: Codable {
    var status: Bool?
    var message: String?
    var data: profileData?
}

// MARK: - DataClass
struct profileData: Codable {
    var userID, name, password, emailID: String?
    var phoneNo, institution, designation, createdOn: String?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name, password
        case emailID = "email_id"
        case phoneNo = "phone_no"
        case institution, designation
        case createdOn = "created_on"
    }
}




struct Editprofilephoto: Codable {
    let status: String
    let data: ProfileMODEL
}

// MARK: - DataClass
struct ProfileMODEL: Codable {
    let profilePhoto: String

    enum CodingKeys: String, CodingKey {
        case profilePhoto = "Profile_photo"
    }
}


// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}
