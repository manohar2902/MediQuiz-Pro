import Foundation

struct Insertanswer: Codable {
    let status, message: String
}

struct Totalscore: Codable {
    let status, message: String
}

struct Correctanswer: Codable {
    let status, message: String
    let matchedAnswersArray: [MatchedAnswersArray]

    enum CodingKeys: String, CodingKey {
        case status, message
        case matchedAnswersArray = "matched_answers_array"
    }
}
struct Wronganswer: Codable {
    let status, message: String
    let unmatchedAnswersArray: [MatchedAnswersArray]

    enum CodingKeys: String, CodingKey {
        case status, message
        case unmatchedAnswersArray = "unmatched_answers_array"
    }
}

// MARK: - MatchedAnswersArray
struct MatchedAnswersArray: Codable {
    let caseStudyID: Int
    let caseStudy: String
    let questionID: Int
    let question,matchedOption : String
    let userAnswer : String
}

// MARK: - Insertquestions
struct Insertquestions : Codable {
    let message,status : String
}
struct Showscore: Codable {
    let status: String
    let totalScore, totalWrong: Int

    enum CodingKeys: String, CodingKey {
        case status
        case totalScore = "total_score"
        case totalWrong = "total_wrong"
    }
}



