//
//  HistoryQuestionsModel.swift
//  Mediquiz
//
//  Created by Prasanth on 12/02/24.
//

import Foundation

// MARK: - Showquestions
struct HistoryQuestionsModel: Codable {
    var historyQuestions: [HistoryQuestion]
    init(historyQuestions: [HistoryQuestion]) {
           self.historyQuestions = historyQuestions
       }
       init() {
           self.historyQuestions = []
       }
    enum CodingKeys: String, CodingKey {
        case historyQuestions = "questions"
    }
}

// MARK: - Question
struct HistoryQuestion: Codable {
    let id, caseStudy, photo: String
    let subQuestions: [HistorySubQuestion]

    enum CodingKeys: String, CodingKey {
        case id
        case caseStudy = "Case_Study"
        case photo
        case subQuestions = "sub_questions"
    }
}

// MARK: - SubQuestion
struct HistorySubQuestion: Codable {
    let id, caseStudyID, questionID, question: String
    let option1, option2, option3, option4: String
    let correctAnswer: String

    enum CodingKeys: String, CodingKey {
        case id
        case caseStudyID = "case_study_id"
        case questionID = "question_id"
        case question
        case option1 = "option_1"
        case option2 = "option_2"
        case option3 = "option_3"
        case option4 = "option_4"
        case correctAnswer = "correct_answer"
    }
}
