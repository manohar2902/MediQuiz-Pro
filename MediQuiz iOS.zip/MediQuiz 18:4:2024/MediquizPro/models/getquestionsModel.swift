import Foundation
////
//
//
//struct Questionaire: Codable {
//    let status: String
//    let caseStudies: [CaseStudy]
//
//    enum CodingKeys: String, CodingKey {
//        case status
//        case caseStudies = "case_studies"
//    }
//}
//
//struct CaseStudy: Codable {
//    let casestudyID: Int
//    let casestudyName: String
//    let casestudyPhoto: String
//    let questions: [Question]
//
//    enum CodingKeys: String, CodingKey {
//        case casestudyID = "case_study_id"
//        case casestudyName = "case_study_name"
//        case casestudyPhoto = "case_study_photo"
//        case questions
//    }
//}
//
//struct Question: Codable {
//    let questionID: Int
//    let questionTitle: String
//    let optionsData: [OptionsDetails]
//    let correctOption: String
//    let selectedOption: Int
//
//    enum CodingKeys: String, CodingKey {
//        case questionID
//        case questionTitle = "question"
//        case optionsData
//        case correctOption = "correctAnswer"
//        case selectedOption
//    }
//}
//
//struct OptionsDetails: Codable {
//    let optionID: Int
//    let optionDesc: String
//    // let isSelected: Bool - need to create in Xcode
//}
//
struct Questionaire: Codable {
    let status, message: String
    let data : [CaseStudy]
}

// MARK: - Datum
struct CaseStudy: Codable {
    let id: Int
    let caseStudy: String
    let photo: String
    let subQuestions: [SubQuestion]

    enum CodingKeys: String, CodingKey {
        case id
        case caseStudy = "Case_Study"
        case photo
        case subQuestions = "sub_questions"
    }
}

// MARK: - SubQuestion
struct SubQuestion: Codable {
    let questionID: Int
    let question: String
    let options: [Option]
    let correctAnswer: Int

    enum CodingKeys: String, CodingKey {
        case questionID = "question_id"
        case question, options
        case correctAnswer = "correct_answer"
    }
}

// MARK: - Option
struct Option: Codable {
    let optionID: Int
    let optionDesc: String

    enum CodingKeys: String, CodingKey {
        case optionID = "option_id"
        case optionDesc = "option_desc"
    }
}

struct Checking: Codable {
    let status, message: String
}
