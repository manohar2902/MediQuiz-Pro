//
//  TestStatus.swift
//  Mediquiz
//
//  Created by SAIL L1 on 01/04/24.
//

import Foundation
struct TestStatusResponse : Codable {
    let status : Int
    var message : String
}
