import Foundation

// MARK: - Welcome
// MARK: - Welcome
struct LoginModel: Codable {
    let status: Bool
    let message: String
    let data: LoginData
}

// MARK: - DataClass
struct LoginData: Codable {
    let userID, password, designation: String

    enum CodingKeys: String, CodingKey {
       
        case userID = "user_id"
        case password
        case designation = "designation"
    }
}


struct Editprofilemodel: Codable {
    let status: String
    let message: String
}
