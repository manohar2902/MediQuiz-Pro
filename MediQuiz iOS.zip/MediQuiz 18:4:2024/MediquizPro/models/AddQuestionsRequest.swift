//
//  AddQuestionsRequest.swift
//  s
//
//  Created by SAIL on 05/02/24.
//

import Foundation
struct CaseStudyCountResponse : Codable {
    let status : String
    let casestudyCount : Int
    enum CodingKeys : String, CodingKey {
        case status
        case casestudyCount = "total_rows"
    }
}
struct AddCaseStudyRequest : Codable {
    let caseStudyID : Int
    let caseStudyName : String
    let caseStudyImage : String
    enum CodingKeys : String, CodingKey {
        case caseStudyID = "id"
        case caseStudyName = "Case_Study"
        case caseStudyImage = "base64ImageString"
    }
}
struct AddQuestionsRequest : Codable {
    let caseStudyID : Int
    let questions : [Question]
    
}
struct Question: Codable {
    let questionID: Int
    let option1, option2, option3, option4: String
    let correctAnswer: Int
    let question: String

    enum CodingKeys: String, CodingKey {
        case questionID = "question_id"
        case option1 = "option_1"
        case option2 = "option_2"
        case option3 = "option_3"
        case option4 = "option_4"
        case correctAnswer = "correct_answer"
        case question
    }
}
struct AddQuestionsResponse : Codable {
    let message : String
    let status : String
}


