//
//  questionSectionTVC.swift
//  s
//
//  Created by SAIL L1 on 04/01/24.
//

import UIKit

class questionSectionTVC: UITableViewCell {

    @IBOutlet weak var casestudyNameLbl: UILabel!
    @IBOutlet weak var casestudyImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        casestudyImg.layer.cornerRadius = 3.0
        
      
    }
   

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
