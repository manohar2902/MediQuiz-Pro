//
//  ReviewSectionTableViewCell.swift
//  MediquizPro
//
//  Created by SAIL on 14/10/23.
//

import UIKit

class ReviewSectionTableViewCell: UITableViewCell {

    @IBOutlet weak var answer: UILabel!
    @IBOutlet weak var textView: UITextView!
    override func awakeFromNib() {
        super.awakeFromNib()
      
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
   

}
