//
//  CheckAnswerCell.swift
//  MediquizPro
//
//  Created by SAIL L1 on 30/12/23.
//

import UIKit

class CheckAnswerCell: UITableViewCell {
    @IBOutlet weak var caseStudyView: UITextView!
    @IBOutlet weak var questionLbl: UILabel!
    @IBOutlet weak var answerLbl: UILabel!
    @IBOutlet weak var rightOrwrongAnsLbl: UILabel!
    @IBOutlet weak var userAnswer: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 10
    }
}
