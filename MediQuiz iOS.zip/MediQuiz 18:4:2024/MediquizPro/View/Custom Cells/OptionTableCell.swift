//
//  OptionTableCell.swift
//  MediquizPro
//
//  Created by SAIL L1 on 28/12/23.
//

import UIKit

class OptionTableCell: UITableViewCell {
    
    
    
    
    @IBOutlet weak var optioLbl: UILabel!
    

    @IBOutlet weak var selectBtn: UIButton!
    
    
    
    
    var selectedOption1:((Int) -> ())?
    var selectedOption2:((Int) -> ())?
    var selectedOption3:((Int) -> ())?
    var selectedOption4:((Int) -> ())?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let margin = UIEdgeInsets(top: 2, left: 2, bottom: 2, right: 2)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 8
    }
    
    
    
//    @IBAction func tapSelect(_ sender: UIButton) {
//        
//        switch sender.tag {
//        case 0:
//            selectedOption1?(0)
//        case 1:
//            selectedOption2?(1)
//        case 2:
//            selectedOption3?(2)
//        case 3:
//            selectedOption4?(3)
//        default:
//            print("")
//        }
//    }
//    
    
    
}
