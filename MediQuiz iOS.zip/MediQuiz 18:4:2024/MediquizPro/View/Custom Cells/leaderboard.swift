//
//  leaderboard.swift
//  MediquizPro
//
//  Created by SAIL on 12/10/23.
//

import UIKit

class leaderboard: UITableViewCell {

    @IBOutlet weak var name: UILabel!

    @IBOutlet weak var rank_no: UILabel!
    @IBOutlet weak var score: UILabel!
    @IBOutlet weak var rank: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
}
