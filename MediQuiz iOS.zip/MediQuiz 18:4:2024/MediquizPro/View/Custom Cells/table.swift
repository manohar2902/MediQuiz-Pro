//
//  table.swift
//  MediquizPro
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class table: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var rank_no: UILabel!
    
    @IBOutlet weak var rank: UIImageView!
        
    @IBOutlet weak var marks: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
