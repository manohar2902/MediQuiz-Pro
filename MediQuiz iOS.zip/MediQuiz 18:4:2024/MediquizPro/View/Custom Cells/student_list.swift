//
//  student_list.swift
//  MediquizPro
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class student_list: UITableViewCell {

    @IBOutlet weak var name: UILabel!

    @IBOutlet weak var marks: UILabel!
    @IBOutlet weak var view: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
      
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    override func layoutSubviews() {
     super.layoutSubviews()
    
    let margin = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
     contentView.frame = contentView.frame.inset(by: margin)
       contentView.layer.cornerRadius = 15
        contentView.layer.shadowOffset = CGSize(width: 0, height: 3)
        contentView.layer.shadowRadius = 3
        contentView.layer.shadowOpacity = 0.8
        contentView.layer.shadowColor = UIColor.red.cgColor
        
        
   }
   
    
}
