//
//  questionscell.swift
//  MediquizPro
//
//  Created by SAIL on 12/10/23.
//

import UIKit

class questionscell: UITableViewCell {
   
    @IBOutlet weak var Enter_option1: UITextField!
    @IBOutlet weak var Enter_option2: UITextField!
    @IBOutlet weak var Enter_option3: UITextField!
   
    @IBOutlet weak var Enter_CorrectAnswer: UITextField!
    
    
    
    @IBOutlet weak var enterAnswerFour: UITextField!
    
    @IBOutlet weak var case_study: UITextView!
    @IBOutlet weak var question_no: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
