//
//  CaseStudyCell.swift
//  MediquizPro
//
//  Created by SAIL on 28/11/23.
//

import UIKit

class CaseStudyCell: UITableViewCell {

    @IBOutlet weak var caseLbl: UILabel!
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var tabelViewHeight: NSLayoutConstraint!
    @IBOutlet weak var questionTable: UITableView!
    
    var questionModel = [HistorySubQuestion]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        questionTable.delegate = self
        questionTable.dataSource = self
        let nib = UINib(nibName: "QuestionCell", bundle: nil)
        questionTable.register(nib, forCellReuseIdentifier: "cell")
        
        tabelViewHeight.constant = CGFloat(1200)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 10
    }
}


extension CaseStudyCell: UITableViewDelegate,UITableViewDataSource {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return questionModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! QuestionCell
        cell.questionCountLbl.text = "\(indexPath.row + 1) :"
        cell.questionLbl.text = questionModel[indexPath.row].question
        cell.optionOne.text = questionModel[indexPath.row].option1
        cell.optionTwoLbl.text = questionModel[indexPath.row].option2
        cell.optionThreeLbl.text = questionModel[indexPath.row].option3
        cell.optionFourLbl.text = questionModel[indexPath.row].option4
        
//        cell.questionLbl.text = questionModel[indexPath.row].text
//        cell.optionOne.text =  questionModel[indexPath.row].options.option1
//        cell.optionTwoLbl.text =  questionModel[indexPath.row].options.option2
//        cell.optionThreeLbl.text =  questionModel[indexPath.row].options.option3
//        cell.optionFourLbl.text =  questionModel[indexPath.row].options.option4
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300.0 
    }
    
 
    
}
