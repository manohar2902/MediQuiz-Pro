//
//  QuestionCell.swift
//  MediquizPro
//
//  Created by SAIL on 28/11/23.
//

import UIKit

class QuestionCell: UITableViewCell {
    
    
    
    @IBOutlet weak var questionCountLbl: UILabel!
    
    
    @IBOutlet weak var questionLbl: UILabel!
    
    
    
    
    @IBOutlet weak var optionOne: UILabel!
    
    @IBOutlet weak var optionTwoLbl: UILabel!
    

    @IBOutlet weak var optionThreeLbl: UILabel!
    
    
    @IBOutlet weak var optionFourLbl: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
    let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 10
    }
}
