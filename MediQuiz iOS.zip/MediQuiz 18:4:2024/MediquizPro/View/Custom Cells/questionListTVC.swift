//
//  questionListTVC.swift
//  s
//
//  Created by SAIL L1 on 04/01/24.
//

import UIKit
protocol QuestionListDelegate : AnyObject {
   func didSelectOption(questionId : Int,selectedOption : Int)
    func updateSelectedOption(questionId: Int, selectedOption: Int)
}

class questionListTVC: UITableViewCell {
    @IBOutlet weak var questionNameLbl: UILabel!
    @IBOutlet weak var option1Lbl: UILabel!
    @IBOutlet weak var option2Lbl: UILabel!
    @IBOutlet weak var option3Lbl: UILabel!
    @IBOutlet weak var option4Lbl: UILabel!
    @IBOutlet weak var option1Img: UIImageView!
    @IBOutlet weak var option2Img: UIImageView!
    @IBOutlet weak var option3Img: UIImageView!
    @IBOutlet weak var option4Img: UIImageView!
    var selectedOption = 0
    var selectedQuestionId = 0
    var delegate1 : QuestionListDelegate?
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
//    override func prepareForReuse() {
//        unselectOptions()
//    }
    internal func updateUI() {
          option1Img.image = selectedOption == 1 ? UIImage(named: "select") : UIImage(named: "unselect")
          option2Img.image = selectedOption == 2 ? UIImage(named: "select") : UIImage(named: "unselect")
          option3Img.image = selectedOption == 3 ? UIImage(named: "select") : UIImage(named: "unselect")
          option4Img.image = selectedOption == 4 ? UIImage(named: "select") : UIImage(named: "unselect")
      }

    func unselectOptions() {
        option1Img.image = UIImage(named: "unselect")
        option2Img.image = UIImage(named: "unselect")
        option3Img.image = UIImage(named: "unselect")
        option4Img.image = UIImage(named: "unselect")
    }
    @IBAction func onOption(_ sender: UIButton ) {
        selectedOption = sender.tag
        updateUI()
        delegate1?.didSelectOption(questionId: selectedQuestionId, selectedOption: selectedOption)
        delegate1?.updateSelectedOption(questionId: selectedQuestionId, selectedOption: selectedOption)

    }
}
