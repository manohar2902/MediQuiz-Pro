//
//  progress_bar.swift
//  MediquizPro
//
//  Created by SAIL on 18/11/23.
//

import UIKit

class progressbar: UIViewController {

    @IBOutlet weak var progressView2: UIView!
    @IBOutlet weak var progressView: UIView!
    var scoreData:Showscore?
    //var pid: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        scoreAPI(user_id: UserDefaults.standard.string(forKey: "userID") ?? "")
    }
    override func viewWillAppear(_ animated: Bool) {
        scoreAPI(user_id: UserDefaults.standard.string(forKey: "userID") ?? "")
    }
    func scoreAPI(user_id:String){
        let formData:[String:String] = [
            "user_id": user_id
        ]
        APIHandler().postAPIValues(type: Showscore.self, apiUrl: ServiceAPI.scoreurl, method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.scoreData = data
                   self.setProgressBar(correct: CGFloat(data.totalScore),wrong: CGFloat(data.totalWrong))
                }
            case .failure(let error):
                // Handle the failure case
                print("API request failed with error: \(error)")
            }
          }
    }
    func setProgressBar(correct:CGFloat,wrong:CGFloat) {
        
        // Create an instance of PercentageProgressBarView
        let progressBarView = PercentageProgressBarView(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
        let progressBarView2 = PercentageProgressBarView(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
                
                // Customize progressBarView if needed
        progressBarView.progressBarColor = UIColor.orange
        progressBarView2.progressBarColor = UIColor.orange

                // Set the percentage and custom text
                progressBarView.setPercentage(correct, customText: "Correct Answers")
        progressBarView2.setPercentage(wrong, customText: "Wrong Answers")

                // Add progressBarView as a subview to yourContainerView
        progressView.addSubview(progressBarView)
        progressView2.addSubview(progressBarView2)

                // Set constraints to position progressBarView within yourContainerView if needed
                progressBarView.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    progressBarView.centerXAnchor.constraint(equalTo: progressView.centerXAnchor),
                    progressBarView.centerYAnchor.constraint(equalTo: progressView.centerYAnchor),
                    progressBarView.widthAnchor.constraint(equalToConstant: 200),
                    progressBarView.heightAnchor.constraint(equalToConstant: 200)
                ])
        
        progressBarView2.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            progressBarView2.centerXAnchor.constraint(equalTo: progressView2.centerXAnchor),
            progressBarView2.centerYAnchor.constraint(equalTo: progressView2.centerYAnchor),
            progressBarView2.widthAnchor.constraint(equalToConstant: 200),
            progressBarView2.heightAnchor.constraint(equalToConstant: 200)
        ])
    }
    @IBAction func nextbtn(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "last_page")
        as! last_page
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func review(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ReviewVc")
        as! ReviewVc
        self.navigationController?.pushViewController(vc, animated:true)
    }
}
