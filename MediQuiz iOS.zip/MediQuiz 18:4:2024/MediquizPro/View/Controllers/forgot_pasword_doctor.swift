//
//  forgot_pasword_doctor.swift
//  MediquizPro
//
//  Created by SAIL on 25/10/23.
//

import UIKit

class forgot_pasword_doctor: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    
    @IBAction func onsave(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Doctorlogin")
        as! Doctorlogin
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
}
