//
//  InitialViewController.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class InitialViewController: ViewController {

    @IBOutlet weak var doctorlogin: UIButton!
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var studentlogin: UIButton!
    
    var pid: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doctorlogin.layer.shadowColor = UIColor.black.cgColor
        doctorlogin.layer.shadowOffset = CGSize(width: 0, height: 3)
                doctorlogin.layer.shadowOpacity = 0.6
                doctorlogin.layer.shadowRadius = 4
        doctorlogin.layer.cornerRadius=20
        doctorlogin.layer.masksToBounds = false
     
        
        
        studentlogin.layer.shadowColor = UIColor.black.cgColor
        studentlogin.layer.shadowOffset = CGSize(width: 0, height: 3)
                studentlogin.layer.shadowOpacity = 0.6
                studentlogin.layer.shadowRadius = 4
        studentlogin.layer.cornerRadius=20
        studentlogin.layer.masksToBounds = false
     
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2){
            self.rotateimage()
           
            self.animateRadius()
       
        }
    }
        
    
    
    @IBAction func onstudent(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "LoginVC")
        as! LoginVC
        self.navigationController?.pushViewController(vc, animated:true)
      
    }
    
    @IBAction func ondoctor(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Doctorlogin")
        as! Doctorlogin
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    
    
    private func rotateimage(){
        let animation = CABasicAnimation(keyPath: "transform.rotation.z")
        animation.fromValue = 0
        animation.toValue = CGFloat.pi * 4
        animation.duration = 3
        animation.repeatDuration = .infinity
        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        image.layer.add(animation, forKey: nil)
        
    }
    
    private func animateRadius(){
        UIView.animate(withDuration: 3, delay: 0, options: [.repeat, .autoreverse], animations: { [weak self] in self?.image.layer.cornerRadius = 50},
                       completion: nil)
    }
    
}

