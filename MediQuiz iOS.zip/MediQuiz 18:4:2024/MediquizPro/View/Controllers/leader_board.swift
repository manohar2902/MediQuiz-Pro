//
//  leader_board.swift
//  MediquizPro
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class leader_board: UIViewController {
  
    @IBOutlet weak var back: UIButton!
    
    
         
    var namelist = ["Student1","Student2","Student3"]
    var imageList = [UIImage(named: "rank1"), UIImage(named: "rank2"), UIImage(named: "rank3") ]
    var numberlist = ["47/50","46/50","44/50"]
    var leaderboardDetail = [leaderboardmodel]()

    @IBOutlet weak var table: UITableView!
    
    @IBOutlet weak var score: UIView!
    
    let loaderView = loader()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        table.addSubview(loaderView)
        loaderView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            loaderView.centerXAnchor.constraint(equalTo: table.centerXAnchor),
            loaderView.centerYAnchor.constraint(equalTo: table.centerYAnchor)
        ])

       
        
        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "table", bundle: nil), forCellReuseIdentifier: "table")
        
        score.layer.cornerRadius=20
        score.layer.maskedCorners=[.layerMinXMinYCorner,.layerMaxXMinYCorner]
        GetAPI()

    }
  
   
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    func GetAPI() {
         
        
     let apiurl = APIHandler().getAPIValues(type: Welcome.self, apiUrl: "http://172.20.10.8/manohariOS/leaderboard.php", method: "GET") { [self] Result in
            switch Result {
               
            case .success(let data):
                leaderboardDetail = data
                DispatchQueue.main.async {
                    table.reloadData()
                    hideLoader()
                }

                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                       hideLoader()
                   }
                
               }
            
    }
}
    func showLoader(){
        loaderView.startAnimating()
    }
    func hideLoader(){
        loaderView.stopAnimating()
    }
}
extension leader_board: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return leaderboardDetail.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "table", for: indexPath)
        as! table
        cell.name.text = leaderboardDetail[indexPath.row].userID
        cell.rank_no.text = "\(indexPath.row + 1)"
        if indexPath.row < 3 {
        cell.rank.image = imageList[indexPath.row]
        cell.rank_no.text = ""
        }
        
        cell.marks.text = leaderboardDetail[indexPath.row].totalScore
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40.0
    }
}



