//
//  QuestionVC.swift
//  sampleApp
//
//  Created by SAIL on 15/09/23.
//

import UIKit
import CloudKit


class QuestionVC: UIViewController {
    func unselectOptions() {
        print("Unselected Images success hurray")
    }
    
    @IBOutlet weak var caseImage: UIImageView!
    @IBOutlet weak var caseStudyLbl: UITextView!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var submit: UIButton!
    @IBOutlet weak var questiontable : UITableView!
    
    let loaderView = loader()
    
    var timer: Timer?
    var secondsRemaining = 1 * 60
    
    var questionDetailsdata : Questionaire?
    var casestudyList : [CaseStudy] = []
    var questionList : [SubQuestion] = []
    
    var displayedCasestudy : CaseStudy?
    var currentcasestudyIndex : Int = 0
    var selectedBtnTag: Int = 0

    //var totalcasestudyCount = Int()
    
    var selectedOption = 0
    var totalScore = 0
    
    var selectedOption1: Int = 0
    var selectedOption2: Int = 0
    var selectedOption3: Int = 0
    var selectedOption4: Int = 0
    
    var insetAnswerDetailsdata:Insertanswer?
    
    var uid : Int?
    
    var timerStoppedManually = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        questiontable.addSubview(loaderView)
        loaderView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            loaderView.centerXAnchor.constraint(equalTo: questiontable.centerXAnchor),
            loaderView.centerYAnchor.constraint(equalTo: questiontable.centerYAnchor)
        ])

        submit.setTitle("Next", for: .normal)
        self.questiontable.delegate = self
        self.questiontable.dataSource = self
        questiontable.register(UINib.init(nibName: "questionSectionTVC", bundle: nil), forCellReuseIdentifier: "questionSectionTVC")
        questiontable.register(UINib.init(nibName: "questionListTVC", bundle: nil), forCellReuseIdentifier: "questionListTVC")
       
        self.questionAPI()
       //self.questiontable.reloadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        reloadquestion()
        startTimer()
    }
    func reloadquestion() {
        guard let questionDetailsdata = questionDetailsdata else {
                    return
        }
        if currentcasestudyIndex < questionDetailsdata.data.count - 1 {
            submit.setTitle("Next", for: .normal)
        } else if currentcasestudyIndex == questionDetailsdata.data.count - 1 {
            submit.setTitle("Submit", for: .normal)
        }
    }
    @objc func updateTimer(timer: Timer) {
        // Update the timer label and check if the timer has reached 0
        if secondsRemaining > 0 {
            secondsRemaining -= 1
            let minutes = secondsRemaining / 60
            let seconds = secondsRemaining % 60
            
            time.text = String(format: "%02d:%02d", minutes, seconds)
        } else {
            stopTimer()
        }
        
   }
    func stopTimer() {
        timer?.invalidate()
        time.text = "Stop!"
        
        let alertController: UIAlertController
        let isAllQuestionsAnswered = checkAllQuestionsAnswered()
        
        if isAllQuestionsAnswered {
            sendAnswerForCurrentCaseStudy()
            totalscoreAPI(id: uid ?? 0)
            alertController = UIAlertController(title: "Alert", message: "Timer got over", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
                print("OK tapped")
                self.navigateToNextScreen()
            }
            alertController.addAction(okAction)
        } else {
            // If not all questions are answered, still send the answers for the current case study
            sendAnswerForCurrentCaseStudy()
            alertController = UIAlertController(title: "Incomplete", message: "Please answer all questions before proceeding", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                print("OK tapped")
                self.navigateToNextScreen()
            }))
        }
        
        present(alertController, animated: true, completion: nil)
    }


    func handleTimerExpiration() {
        guard !timerStoppedManually else {
            return
        }
        timerStoppedManually = true
        // Reset selected options for the last case study
        selectedOption1 = 0
        selectedOption2 = 0
        selectedOption3 = 0
        selectedOption4 = 0
        stopTimerManually()
    }
    // Call this method when you want to stop the timer manually, for example, when a button is pressed.
    func stopTimerManually() {
        guard timer != nil  else {
            return
        }
        timer?.invalidate()
        timer = nil
    }
    @IBAction func onsubmit(_ sender : Any) {
            guard let questionDetailsdata = questionDetailsdata else {
                return
            }
            let isAllQuestionsAnswered = checkAllQuestionsAnswered()
            if isAllQuestionsAnswered {
                            if currentcasestudyIndex < questionDetailsdata.data.count - 1 {
                sendAnswerForCurrentCaseStudy()
                currentcasestudyIndex += 1
                let nextCasestudy = questionDetailsdata.data[currentcasestudyIndex]
                displayedCasestudy = nextCasestudy
                selectedOption1 = 0
                selectedOption2 = 0
                selectedOption3 = 0
                selectedOption4 = 0
                reloadquestion()
                questiontable.reloadData()
            }
            else if currentcasestudyIndex == questionDetailsdata.data.count - 1 {
                submit.setTitle("Submit", for: .normal)
                print("Current case study index",currentcasestudyIndex)
                sendAnswerForCurrentCaseStudy()
                totalscoreAPI(id: uid ?? 0 )
                showSubmitAlert()
                stopTimerManually()
            }
                    }
          else {
              showAlert(title: "Incomplete", message: "Please answer all questions before proceeding.")
          }
        }
func checkAllQuestionsAnswered() -> Bool {
    // Check if all questions have been answered
    return selectedOption1 != 0 && selectedOption2 != 0 && selectedOption3 != 0 && selectedOption4 != 0
}
    
func showAlert(title: String, message: String) {
    let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
    present(alert, animated: true, completion: nil)
}
    func showSubmitAlert() {
        let alert = UIAlertController(title: "Test Finished", message: "Test finished successfully", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak self] _ in
            self?.navigateToNextScreen()
        }))
        self.present(alert, animated: true)
    }
    func sendAnswerForCurrentCaseStudy() {
        guard let questionDetailsdata = questionDetailsdata else {
            return
        }
        let caseStudyID = questionDetailsdata.data[currentcasestudyIndex].id
        sendAnswerAPI(id: uid ?? 0, caseStudy: caseStudyID, question1: 1, userAnswer1: selectedOption1, question2: 2, userAnswer2: selectedOption2, question3: 3, userAnswer3: selectedOption3, question4: 4, userAnswer4: selectedOption4)
    }

    func navigateToNextScreen() {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "progressbar") as! progressbar
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func navigateToBack(){
        navigationController?.popViewController(animated: true)

    }
    func startTimer() {
        // Schedule a timer to call the "updateTimer" function every second
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    func questionAPI(){
        APIHandler().getAPIValues(type: Questionaire.self, apiUrl: ServiceAPI.getQuestion, method: "GET") { [self] result in
            switch result {
            case .success(let data):
                self.questionDetailsdata = data
                self.casestudyList = self.questionDetailsdata!.data
                DispatchQueue.main.async {
                self.questiontable.reloadData()
                    self.hideLoader()
                
                }
            case .failure(let error):
                print("API request failed with error:\(error)")
                hideLoader()
            }
        }
    }
    func sendAnswerAPI(id : Int, caseStudy : Int,question1 : Int,userAnswer1 : Int,question2 : Int,userAnswer2 : Int,question3 : Int ,userAnswer3 : Int, question4 : Int,userAnswer4 : Int){
        self.showLoader()
        let formData:[String:Any] = [
            "user_id" : id,
            "case_study_id" : caseStudy,
            "question_id_1" : question1,
            "user_answer_1" : userAnswer1,
            "question_id_2" : question2,
            "user_answer_2" : userAnswer2,
            "question_id_3" : question3,
            "user_answer_3": userAnswer3,
            "question_id_4" : question4,
            "user_answer_4" : userAnswer4
        ]
        print("formData : \(formData)")
        APIHandler().postAPIValues(type: Insertanswer.self, apiUrl: ServiceAPI.insertAnswer, method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self.totalscoreAPI(id: self.uid ?? 0)
                    self.hideLoader()
                }
                
            case .failure(_):
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { (action) in
                        print("OK tapped")
                       
                        self.navigateToBack()
                    
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func totalscoreAPI(id : Int){
        let formData:[String:Any] = [
            "user_id" : id,
            ]
        print("formData : \(formData)")
        APIHandler().postAPIValues(type: Totalscore.self, apiUrl: ServiceAPI.totalScore, method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                print(data)
                
            case .failure(let error):
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                        print("JSON Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func showLoader(){
        loaderView.startAnimating()
    }
    func hideLoader(){
        loaderView.stopAnimating()
    }

            
    }
    
    
extension QuestionVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let displayedCasestudy = questionDetailsdata?.data[currentcasestudyIndex].subQuestions else {
            return 0
        }
        return displayedCasestudy.count
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableCell(withIdentifier: "questionSectionTVC") as! questionSectionTVC
        headerView.casestudyNameLbl.text = questionDetailsdata?.data[currentcasestudyIndex].caseStudy

        if let casestudyImageURLString = questionDetailsdata?.data[currentcasestudyIndex].photo,
           let casestudyImageURL = URL(string: casestudyImageURLString) {
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: casestudyImageURL) {
                    DispatchQueue.main.async {
                        headerView.casestudyImg.image = UIImage(data: data)
                        headerView.casestudyImg.contentMode = .scaleAspectFit
                    }
                }
            }
        } else {
            print("Invalid image URL")
        }

        return headerView
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "questionListTVC", for: indexPath) as! questionListTVC

           guard let displayedCasestudy = questionDetailsdata?.data else {
               return cell
           }

           let dict = displayedCasestudy[currentcasestudyIndex].subQuestions[indexPath.row]
           cell.questionNameLbl.text = dict.question
           cell.option1Lbl.text = dict.options[0].optionDesc
           cell.option2Lbl.text = dict.options[1].optionDesc
           cell.option3Lbl.text = dict.options[2].optionDesc
           cell.option4Lbl.text = dict.options[3].optionDesc
           cell.selectedQuestionId = dict.questionID

           // Set the selected option for the cell based on the question ID
           switch dict.questionID {
               case 1:
                   cell.selectedOption = selectedOption1
               case 2:
                   cell.selectedOption = selectedOption2
               case 3:
                   cell.selectedOption = selectedOption3
               case 4:
                   cell.selectedOption = selectedOption4
               default:
                   break
           }

           cell.updateUI()
           cell.delegate1 = self
           return cell
       }

       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           tableView.deselectRow(at: indexPath, animated: true)
           tableView.reloadData() // Ensure table view is reloaded after selecting an option
       }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 250.0
        //return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300.0
    }
}
extension QuestionVC : QuestionListDelegate {
    func updateSelectedOption(questionId: Int, selectedOption: Int) {
        switch questionId {
            case 1:
                self.selectedOption1 = selectedOption
            case 2:
                self.selectedOption2 = selectedOption
            case 3:
                self.selectedOption3 = selectedOption
            case 4:
                self.selectedOption4 = selectedOption
            default:
                break
        }
    }

    func didSelectOption(questionId: Int, selectedOption: Int) {
        updateSelectedOption(questionId: questionId, selectedOption: selectedOption)
    }
}

