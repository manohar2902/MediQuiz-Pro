import UIKit

class SignInVC: UIViewController, DropdownViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    func didSelectItem(_ item: String) {
        if designation.isFirstResponder {
            designation.text = item
            dropdownvalue = item
            designation.resignFirstResponder()
        }
    }
    @IBOutlet weak var onadd: UIButton!
    @IBOutlet weak var onview: UIView!
    @IBOutlet weak var user_id: UITextField!
    @IBOutlet weak var re_enter_password: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var designation: UITextField!
    @IBOutlet weak var institution: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var phone_no: UITextField!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var Pimage: UIImageView!
    @IBOutlet weak var create: UIButton!
    let imagePicker = UIImagePickerController()
    var selectedImage = [UIImage]()
    var mobilenumberLimit = 10
    private var dropdownView: DropdownView!
    let loaderView = loader()
    var dropdownvalue: String = ""
   
    override func viewDidLoad() {
        super.viewDidLoad()
        setupDelegate()
        phone_no.keyboardType = .numberPad
        phone_no.delegate = self
        imagePicker.delegate = self
        let dropdownData = [" ", "Student", "Doctor"]
        dropdownView = DropdownView(data: dropdownData)
        dropdownView.dropdownDelegate = self
        designation.inputView = dropdownView
        onview.addSubview(loaderView)
        loaderView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            loaderView.centerXAnchor.constraint(equalTo: onview.centerXAnchor),
            loaderView.centerYAnchor.constraint(equalTo: onview.centerYAnchor)
        ])
        
        Pimage.layer.cornerRadius = Pimage.frame.size.width / 2
                Pimage.clipsToBounds = true
        
        setupTapGestureToDismissKeyboard()
    }
    
  
    @IBAction func ONADD(_ sender: Any) {
        PresentImagePicker()
    }
    func PresentImagePicker() {
                      let alert = UIAlertController(title: "Choose Media", message: nil, preferredStyle: .actionSheet)
                      alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
                          self.openCamera() // Call openCamera() from within PresentImagePicker()
                      }))
                      alert.addAction(UIAlertAction(title: "Choose Image", style: .default, handler: { _ in
                          self.openGallery()
                      }))
                      alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
                      present(alert, animated: true, completion: nil)
        }
    func openCamera() {
                  if UIImagePickerController.isSourceTypeAvailable(.camera) {
                      imagePicker.sourceType = .camera
                      present(imagePicker, animated: true, completion: nil)
                  } else {
                      print("Camera not available")
                  }
    }
   func openGallery() {
       imagePicker.sourceType = .photoLibrary
       present(imagePicker, animated: true, completion: nil)
   }
func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
       if let image = info[.originalImage] as? UIImage {
           selectedImage.append(image)
           Pimage.image = image
          // uploadProfileWithImage(image: image)
       } else {
           Pimage.image = UIImage(named: "profile_photo")
       }
       picker.dismiss(animated: true, completion: nil)
   }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    @IBAction func oncreate(_ sender: Any) {
        showLoader()
        guard isValidName() else {
            return
        }
        guard isValidPhone() else {
            return
        }
        guard isValidID() else {
            return
        }
        guard isValidPassword() else {
            showAlert(title: "Error", message: "Please enter a valid password")
            return
        }
        guard isValidinstitution() else {
            showAlert(title: "Error", message: "Please enter a valid speciality")
            return
        }
        guard isValiddesignation() else {
            showAlert(title: "Error", message: "Please enter a valid speciality")
            return
        }
        guard isValidemail() else {
            showAlert(title: "Error", message: "Please enter a valid speciality")
            return
        }
        guard isValidre_enter_password() else {
            showAlert(title: "Error", message: "Please enter a valid speciality")
            return
        }
           
        registerUser()
    }
    func setupDelegate() {
        name.delegate = self
        phone_no.delegate = self
        password.delegate = self
        institution.delegate = self
        designation.delegate = self
        email.delegate = self
        re_enter_password.delegate = self
        user_id.delegate = self
        
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func isValidMobileNumber(_ mobileNumber: String?) -> Bool {
        guard let mobile = mobileNumber, !mobile.isEmpty else {
            return false
        }
        let numericCharacterSet = CharacterSet(charactersIn: "0123456789")
        let isNumeric = mobile.rangeOfCharacter(from: numericCharacterSet.inverted) == nil
        return isNumeric
    }
    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        if textField == phone_no {
//            // Allow only numeric input
//            let allowedCharacters = CharacterSet(charactersIn: "0123456789")
//            let characterSet = CharacterSet(charactersIn: string)
//            return allowedCharacters.isSuperset(of: characterSet) && (textField.text?.count ?? 0) + string.count - range.length <= 10
//        }
//        return true
//    }

    func showLoader() {
        loaderView.startAnimating()
    }
    
    func hideLoader() {
        loaderView.stopAnimating()
    }
    
    func registerUser()   {
        let formData = [
            "name": name.text ?? "",
            "phone_no": phone_no.text ?? "",
            "email_id": email.text ?? "",
            "institution": institution.text ?? "",
            "designation": designation.text ?? "",
            "password": password.text ?? "",
            "re_password": re_enter_password.text ?? "",
            "user_id": user_id.text ?? "",
        ]
        let fieldNames = ["profile_photo"]
        APIHandler().postMultipartAPI(apiURL: ServiceAPI.signupUrl, formData: formData, fieldNames: fieldNames, selectedImages: selectedImage, responseType: sigupJSON.self) { result in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    if response.status == "success" {
                        let alert = UIAlertController(title: "Success", message: response.message, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                            self.navigationController?.popViewController(animated: true)
                        }))
                        self.present(alert, animated: true)
                    }
                    else if response.status == "error" {
                        let alert = UIAlertController(title: "Error", message: response.message, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alert, animated: true)
                        
                    }
                }
            case .failure(let error):
                print("Error : \(error)")
            }
        }
    }
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true)
    }
}
    
extension SignInVC {
    func setupTapGestureToDismissKeyboard() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tapGesture.cancelsTouchesInView = false // Allow other gesture recognizers to work alongside this one
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
extension SignInVC : UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == phone_no {
            let currentString : NSString = (textField.text ?? "") as NSString
            let newString : NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= mobilenumberLimit
        }
        return true
    }
    func isValidName() -> Bool {
        guard let name = name.text, !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showAlert(title: "Error", message: "Please enter a valid name")
            return false
        }
        return true
    }
    func isValidPhone() -> Bool {
        guard let phoneNumber = phone_no.text, !phoneNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,phoneNumber.count == mobilenumberLimit else {
            showAlert(title: "Error", message: "Please enter a valid 10-digit phone number")
            return false
        }
        return true
    }
    func isValidID() -> Bool {
        guard let userid = user_id.text, !userid.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showAlert(title: "Error", message: "Please enter a valid doctor ID ")
            return false
        }
        return true
    }
    func isValidPassword() -> Bool {
        guard let password = password.text, !password.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showAlert(title: "Error", message: "Please enter a valid password ")
            return false
        }
        return true
    }
    func isValidinstitution() -> Bool {
        guard let institution = institution.text, !institution.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showAlert(title: "Error", message: "Please enter a speciality")
            return false
        }
        return true
    }
    func isValiddesignation() -> Bool {
        guard let designation = designation.text, !designation.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showAlert(title: "Error", message: "Please enter a speciality")
            return false
        }
        return true
    }
    func isValidemail() -> Bool {
        guard let email = email.text, !email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showAlert(title: "Error", message: "Please enter a speciality")
            return false
        }
        return true
    }
    func isValidre_enter_password() -> Bool {
        guard let re_enter_password = re_enter_password.text, !re_enter_password.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showAlert(title: "Error", message: "Please enter a speciality")
            return false
        }
        return true
    }
}
