//
//  DoctorHomeVC.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class DoctorHomeVC: ViewController {
    @IBOutlet weak var leader_board: UIButton!
    
    @IBOutlet weak var proflie: UIButton!
    @IBOutlet weak var add: UIButton!
    @IBOutlet weak var studentslist: UIButton!
    @IBOutlet weak var history: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        studentslist.layer.shadowColor = UIColor.black.cgColor
        studentslist.layer.shadowOffset = CGSize(width: 0, height: 3)
                studentslist.layer.shadowOpacity = 0.6
                studentslist.layer.shadowRadius = 4
        studentslist.layer.cornerRadius=20
        studentslist.layer.masksToBounds = false
        
        history.layer.shadowColor = UIColor.black.cgColor
        history.layer.shadowOffset = CGSize(width: 0, height: 3)
                history.layer.shadowOpacity = 0.6
                history.layer.shadowRadius = 4
        history.layer.cornerRadius=20
        history.layer.masksToBounds = false
        add.layer.shadowColor = UIColor.black.cgColor
        add.layer.shadowOffset = CGSize(width: 0, height: 3)
                add.layer.shadowOpacity = 0.6
                add.layer.shadowRadius = 4
        add.layer.cornerRadius=20
        add.layer.masksToBounds = false

       
    }
    
    @IBAction func onleader(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "leader_board")
        as! leader_board
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func onhistory(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "QuestionHistoryVC")
        as! QuestionHistoryVC
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func onlist(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "studentlist")
        as! studentlist
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func onadd(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "adding_question")
        as! adding_question
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func onproflie(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ProfileVC")
        as! ProfileVC
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func onlogout(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "InitialViewController")
        as! InitialViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
}
