//
//  Doctorleaderboard.swift
//  MediquizPro
//
//  Created by SAIL on 12/10/23.
//

import UIKit

class Doctorleaderboard: UIViewController {
    
    

    @IBOutlet weak var back: UIButton!
    
    @IBOutlet weak var table: UITableView!

    @IBOutlet weak var score: UIView!
    
    var namelist = ["Student1","Student2","Student3"]
    var imageList = [UIImage(named: "rank1"), UIImage(named: "rank2"), UIImage(named: "rank3") ]
    var numberlist = ["47/50","46/50","44/50"]
    
    var leaderboardDetail = [leaderboardmodel]()
    var pid: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        score.layer.cornerRadius=20
        score.layer.maskedCorners = [.layerMinXMinYCorner,.layerMaxXMinYCorner]
        
        
        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "leaderboard", bundle: nil), forCellReuseIdentifier: "leaderboard")
        
        GetAPI()
    }
    
    
    
    func GetAPI() {
        
        
     let apiurl = APIHandler().getAPIValues(type: Welcome.self, apiUrl: "http://172.20.10.8/manohariOS/leaderboard.php", method: "GET") { [self] Result in
            switch Result {
               
            case .success(let data):
                leaderboardDetail = data
                DispatchQueue.main.async {
                    table.reloadData()
                }

                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
            
    }
}
  
   
    

    @IBAction func onback(_ sender: Any) {
//        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyBoard.instantiateViewController(withIdentifier: "HomeViewController")
//        as! HomeViewController
//        self.navigationController?.pushViewController(vc, animated:true)
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension Doctorleaderboard: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return leaderboardDetail.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "leaderboard", for: indexPath)
        as! leaderboard
        cell.name.text = leaderboardDetail[indexPath.row].userID
        cell.rank_no.text = "\(indexPath.row + 1)"
        if indexPath.row < 3 {
        cell.rank.image = imageList[indexPath.row]
        cell.rank_no.text = ""
        }
        
        cell.score.text = leaderboardDetail[indexPath.row].totalScore
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40.0
    }
}
