//
//  ProfileVC.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class ProfileVC: ViewController {

    @IBOutlet weak var designation: UILabel!
    @IBOutlet weak var institution: UILabel!
    @IBOutlet weak var profileimsage: UIImageView!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var mobile_no: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var back: UIButton!
    
    let apiHandler : APIHandler = APIHandler()
    var apiData : profilemodel!
    var apiUrl = String()
    var profileData: (name: String, mail: String, mobile: String, insti: String, des: String)?
    var pid: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        profileimsage.layer.cornerRadius = 55
        setupTapGestureToDismissKeyboard()
       
    }
    override func viewWillAppear(_ animated: Bool) {
    
       
        GetAPI(user_id: UserDefaults.standard.string(forKey: "userID") ?? "")
    
        func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
        func GetAPI(user_id:String){
        
            apiHandler.getAPIValues(type: profilemodel.self, apiUrl: ServiceAPI.profileAPI+"?user_id=\(String(describing: user_id))", method: "GET") { [self] result in
                switch result {
                case .success(let data):
                    self.apiData = data
                    print(data)
                    DispatchQueue.main.async {
                        name.text = apiData.data?.name
                        mobile_no.text = apiData.data?.phoneNo
                        email.text = apiData.data?.emailID
                        institution.text = apiData.data?.institution
                        designation.text = apiData.data?.designation
                       
                            fetchProfileImage()
                        
                       
                    }
                    
                    
                case .failure(let error):
                    print(error)
                    
                }
            }
            
        }
    }
    
    @IBAction func onedit(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "EditProfileVC")
        as! EditProfileVC
        vc.userID = UserDefaults.standard.string(forKey: "userID") ?? ""
        if let name = self.name.text, let phone = self.mobile_no.text, let email = self.email.text, let insti = self.institution.text, let des = self.designation.text {
            profileData = (name,email,phone,insti,des)
           
        }
        vc.editProfileData = profileData
        
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func onback(_ sender: Any) {
        navigationController?.popViewController(animated: true)

    }
    
    func fetchProfileImage() {
        
        LoadingIndicator.shared.showLoading(on: view)
                 guard let userID = UserDefaults.standard.string(forKey: "userID") else {
                     print("User ID not available")
                     return
                 }
                 
                 let param = ["user_id": userID]
                 
                 APIHandler.shared.postAPIValues(type: Editprofilephoto.self, apiUrl: ServiceAPI.showphoto, method: "POST", formData: param) { result in
                     switch result {
                     case .success(let data):
                         print(data)
                         DispatchQueue.main.async {
                             // No need for optional binding as profilePhoto is not option
                             LoadingIndicator.shared.hideLoading()
                             self.loadImage(url: data.data.profilePhoto, imageView: self.profileimsage)
                         }
                         
                     case .failure(let error):
                         LoadingIndicator.shared.hideLoading()
                         print(error)
                         
                     }
                 }
             }

}

extension ProfileVC{
    func setupTapGestureToDismissKeyboard() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tapGesture.cancelsTouchesInView = false // Allow other gesture recognizers to work alongside this one
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}



