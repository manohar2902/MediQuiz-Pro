//
//  EditProfileVC.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class EditProfileVC: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var userID: String = ""
    
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var moblieField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var instutionField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var re_enterpasswordField: UITextField!
    @IBOutlet weak var des: UITextField! // Assuming this field replaces the removed dropdownTextField
    
    var user_ID = UserDefaults.standard.string(forKey: "userID")
    
    let loaderView = loader()
    var editProfileData: (name: String, mail: String, mobile: String, insti: String, des: String)?
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchProfileImage()
        
        profileImageView.layer.cornerRadius = 55
        profileImageView.isUserInteractionEnabled = true
        
        imagePicker.delegate = self
        moblieField.keyboardType = .numberPad
        moblieField.delegate = self
        
        if let profileData = editProfileData {
            name.text = profileData.name
            moblieField.text = profileData.mobile
            emailField.text = profileData.mail
            instutionField.text = profileData.insti
            des.text = profileData.des
        }
        
        setupTapGestureToDismissKeyboard()
    }
    
    @IBAction func updatebutton(_ sender: Any) {
        PresentImagePicker()
    }
    
    func registerUseredit() {
        if let userId = user_ID {
            let apiURL = ServiceAPI.editprofileURL
            print(apiURL)
            let formData: [String: String] = [
                "user_id": userId,
                "name": name.text ?? "",
                "phone_no": moblieField.text ?? "",
                "email_id": emailField.text ?? "",
                "institution": instutionField.text ?? "",
                "password": passwordField.text ?? "",
                "designation": des.text ?? "",
                "re_password": re_enterpasswordField.text ?? ""
            ]
            
            APIHandler().postAPIValues(type: Editprofilemodel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        if response.status == "success" {
                            let successAlert = UIAlertController(title: "Success", message: "Update successful", preferredStyle: .alert)
                            successAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(successAlert, animated: true, completion: nil)
                        } else {
                            let failureAlert = UIAlertController(title: "Error", message: "Update failed", preferredStyle: .alert)
                            failureAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(failureAlert, animated: true, completion: nil)
                        }
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        let errorAlert = UIAlertController(title: "Error", message: "Failed to update. Please try again later.", preferredStyle: .alert)
                        errorAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(errorAlert, animated: true, completion: nil)
                    }
                }
            }
        }
    }
    
    @IBAction func save(_ sender: Any) {
        registerUseredit()
    }
    
    func PresentImagePicker() {
        let alert = UIAlertController(title: "Choose Media", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Choose Image", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            profileImageView.image = image
            uploadProfileWithImage(image: image)
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func uploadProfileWithImage(image: UIImage) {
        // Your existing code for uploading profile image
    }
    
    func fetchProfileImage() {
        // Your existing code for fetching and loading profile image
    }
    
    @IBAction func onback(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}

extension EditProfileVC {
    func setupTapGestureToDismissKeyboard() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
