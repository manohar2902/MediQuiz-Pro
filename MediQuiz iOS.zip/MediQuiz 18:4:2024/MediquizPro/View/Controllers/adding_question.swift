

import UIKit

class adding_question: UIViewController, UINavigationControllerDelegate {
    
    @IBOutlet var casestudyNumberLbl: UILabel!
    @IBOutlet weak var add_imagebtn: UIButton!
    @IBOutlet weak var case_study: UITextView!
    @IBOutlet weak var enter_question1: UITextView!
    @IBOutlet weak var upload_image: UIImageView!
    @IBOutlet weak var enter_correctq1: UITextField!
    @IBOutlet weak var enter_optionQ1_1: UITextField!
    @IBOutlet weak var enter_optionQ1_2: UITextField!
    @IBOutlet weak var enter_optionQ1_3: UITextField!
    @IBOutlet weak var enter_optionQ1_4: UITextField!
    @IBOutlet weak var enter_question2: UITextView!
    @IBOutlet weak var enter_correctq2: UITextField!
    @IBOutlet weak var enter_optionQ2_1: UITextField!
    @IBOutlet weak var enter_optionQ2_2: UITextField!
    @IBOutlet weak var enter_optionQ2_3: UITextField!
    @IBOutlet weak var enter_optionQ2_4: UITextField!
    @IBOutlet weak var enter_question3: UITextView!
    @IBOutlet weak var enter_correctq3: UITextField!
    @IBOutlet weak var enter_optionQ3_1: UITextField!
    @IBOutlet weak var enter_optionQ3_2: UITextField!
    @IBOutlet weak var enter_optionQ3_3: UITextField!
    @IBOutlet weak var enter_optionQ3_4: UITextField!
    @IBOutlet weak var enter_question4: UITextView!
    @IBOutlet weak var enter_correctq4: UITextField!
    @IBOutlet weak var enter_optionQ4_1: UITextField!
    @IBOutlet weak var enter_optionQ4_2: UITextField!
    @IBOutlet weak var enter_optionQ4_3: UITextField!
    @IBOutlet weak var enter_optionQ4_4: UITextField!
    var questionTxtPlaceholder = "Enter the question..."
    
    var currentcasestudyID : Int = 0
    var casestudyCount = 0
    var questionsData : [Question] = []
    
    var selectedImage = UIImage()
    var convertImage = Data()
    var conCurrentThread = DispatchGroup()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        enter_question1.delegate = self
        enter_question2.delegate = self
        enter_question3.delegate = self
        enter_question4.delegate = self
        enter_question1.text = questionTxtPlaceholder
        enter_question2.text = questionTxtPlaceholder
        enter_question3.text = questionTxtPlaceholder
        enter_question4.text = questionTxtPlaceholder
        
        self.navigationController?.isNavigationBarHidden = true
        

        self.placeHolder(textView: enter_question1)
        self.placeHolder(textView: enter_question2)
        self.placeHolder(textView: enter_question3)
        self.placeHolder(textView: enter_question4)

    }
    
    
    func placeHolder(textView:UITextView) {
        
        
        textView.text = "Enter your text here..."
        textView.textColor = UIColor.lightGray

               // Clear the placeholder text when the user starts editing
        textView.selectedTextRange = textView.textRange(from: textView.beginningOfDocument, to: textView.beginningOfDocument)
        
    }
    
    
   
       // UITextViewDelegate method to clear the placeholder text when the user begins editing
       func textViewDidBeginEditing(_ textView: UITextView) {
           if textView.textColor == UIColor.lightGray {
               textView.text = nil
               textView.textColor = UIColor.black
           }
       }
    
    
//    func textViewDidBeginEditing(_ textView: UITextView) {
//        if enter_question1.text == "Enter the questions.." {
//            enter_question1.tex = ""
//        }
//        enter_question2.text = ""
//        enter_question3.text = ""
//        enter_question4.text = ""
//
//    }
    override func viewWillAppear(_ animated: Bool) {
        getCaseStudyIDAPI()
    }
    
    @IBAction func add_image(_ sender: Any) {
        let alert = UIAlertController(title: "Candidate Image", message: "Choose Candidate Image ", preferredStyle: .actionSheet)
        let galleryAction : UIAlertAction = UIAlertAction(title: "Photo Library", style: .default) { action -> Void in
            self.openGallery()
        }
        let cancelAction : UIAlertAction = UIAlertAction(title: "Cancel", style: .destructive)
        alert.addAction(galleryAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true)
        add_imagebtn.isHidden = true
        upload_image.isHidden = false
    }
    
    
    @IBAction func onprofile(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onback(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submitTap(_ sender: Any) {
        if case_study.text?.isEmpty ?? true || enter_question1.text?.isEmpty ?? true || enter_question2.text?.isEmpty ?? true || enter_question3.text?.isEmpty ?? true || enter_question4.text?.isEmpty ?? true || enter_correctq1.text?.isEmpty ?? true || enter_correctq2.text?.isEmpty ?? true || enter_correctq3.text?.isEmpty ?? true || enter_correctq4.text?.isEmpty ?? true || enter_optionQ1_1.text?.isEmpty ?? true || enter_optionQ1_2.text?.isEmpty ?? true || enter_optionQ1_3.text?.isEmpty ?? true || enter_optionQ1_4.text?.isEmpty ?? true || enter_optionQ2_1.text?.isEmpty ?? true || enter_optionQ2_2.text?.isEmpty ?? true || enter_optionQ2_3.text?.isEmpty ?? true || enter_optionQ2_4.text?.isEmpty ?? true || enter_optionQ3_1.text?.isEmpty ?? true || enter_optionQ3_2.text?.isEmpty ?? true || enter_optionQ3_3.text?.isEmpty ?? true || enter_optionQ3_4.text?.isEmpty ?? true || enter_optionQ4_1.text?.isEmpty ?? true || enter_optionQ4_2.text?.isEmpty ?? true || enter_optionQ4_3.text?.isEmpty ?? true || enter_optionQ4_4.text?.isEmpty ?? true {
             // Show alert if any of the fields are empty
             let alert = UIAlertController(title: "Alert", message: "Please fill in all the fields.", preferredStyle: .alert)
             alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
             self.present(alert, animated: true, completion: nil)
         } else {
             // Proceed with submission
             self.ConCurrentAPI()
         }
    }
    
    func openGallery() {
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc, animated: true, completion: nil)
    }
    
    private func ConCurrentAPI() {
        conCurrentThread.enter()
        guard let image = UIImage(data: convertImage) else {
            print("NO Image ")
            return
        }
        uploadImage(id: Int(self.currentcasestudyID), caseStudy: case_study.text ?? "", image: image) { result in
            if let response = result {
                print("Image uploaded successfully: \(response)")
                self.conCurrentThread.leave()
            } else {
                print("Error uploading image")
                self.conCurrentThread.leave()
            }
        }
        
        conCurrentThread.enter()
        createQuestionsData { Question in
            print(Question)
            self.saveQuestionsAPI(caseStudyID: self.currentcasestudyID, questions: Question) { result in
                switch result {
                case .success(let data):
                    // Handle success
                    print("Data: \(data)")
                case .failure(let error):
                    // Handle failure
                    print("Error: \(error)")
                }
                // Present alert after both API calls have completed
                DispatchQueue.main.async {
                    self.presentSubmissionAlert()
                }
                self.conCurrentThread.leave()
            }
        }
    }

    func presentSubmissionAlert() {
        let alert = UIAlertController(title: "Success", message: "Submission Successful", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func getCaseStudyIDAPI() {
        APIHandler().getAPIValues(type: CaseStudyCountResponse.self, apiUrl: ServiceAPI.casestudyCount, method: "GET") { result in
            switch result {
            case .success(let data):
                self.casestudyCount = data.casestudyCount
                self.currentcasestudyID = self.casestudyCount + 1
                DispatchQueue.main.async {
                    self.casestudyNumberLbl.text = "Case Study \(self.currentcasestudyID)"
                }
            case .failure(let error):
                print(error,"Failed to get case study count")
            }
        }
    }
    
    func saveQuestionsAPI(caseStudyID: Int, questions: [Question], completion: @escaping (Result<AddQuestionsResponse, Error>) -> Void) {
        // Map array of Question objects to array of dictionaries
        let questionsDict = questions.map { question in
            return [
                "questionID": question.questionID,
                "question": question.question,
                "option1": question.option1,
                "option2": question.option2,
                "option3": question.option3,
                "option4": question.option4,
                "correctAnswer": question.correctAnswer
            ]
        }
        print(questionsDict, "questionsDict")
        // Create dictionary with caseStudyID and questions array
        let requestBody: [String: Any] = [
            "caseStudyID": caseStudyID,
            "questions": questionsDict
        ]
        print(requestBody, "Req")
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody)
            print(jsonData,"jsonData")
            
            APIHandler().postAPIRawJSON(type: AddQuestionsResponse.self, apiUrl: ServiceAPI.addQuestions, method: "POST", jsonData: jsonData) { result in
                switch result {
                case .success(let response):
                    completion(.success(response))
                case .failure(let error):
                    completion(.failure(error))
                }
            }
        } catch {
            print("Error converting JSON data to dictionary: \(error)")
            completion(.failure(error))
        }
    }
    
    func uploadImage(id: Int, caseStudy: String, image: UIImage, completion: @escaping (String?) -> Void) {
        // API endpoint
        guard let url = URL(string: "http://172.20.10.8/manohariOS/insert_casestudy.php") else {
            completion(nil)
            return
        }
        
        let boundary = "Boundary-\(UUID().uuidString)"
        let mimeType = "image/png" // Set the image mime type accordingly
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        let body = NSMutableData()
        
        // Add id parameter to the form data
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"id\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(id)\r\n".data(using: .utf8)!)
        
        // Add Case_Study parameter to the form data
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"Case_Study\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(caseStudy)\r\n".data(using: .utf8)!)
        
        // Add image data to the form data
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"photo\"; filename=\"image.png\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
        
        if let imageData = image.pngData() {
            body.append(imageData)
        }
        
        body.append("\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body as Data
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                completion(error?.localizedDescription)
                return
            }
            
            if let responseString = String(data: data, encoding: .utf8) {
                completion(responseString)
            } else {
                completion(nil)
            }
        }.resume()
    }
    
    
    func getOptionText(for questionNumber: Int, option: Int) -> String {
        switch (questionNumber, option) {
            // Cases for each question and option
        case (1, 1): return enter_optionQ1_1.text ?? ""
        case (1, 2):
            return enter_optionQ1_2.text ?? ""
        case (1, 3):
            return enter_optionQ1_3.text ?? ""
        case (1, 4):
            return enter_optionQ1_4.text ?? ""
        case (2, 1):
            return enter_optionQ2_1.text ?? ""
        case (2, 2):
            return enter_optionQ2_2.text ?? ""
        case (2, 3):
            return enter_optionQ2_3.text ?? ""
        case (2, 4):
            return enter_optionQ2_4.text ?? ""
        case (3, 1):
            return enter_optionQ3_1.text ?? ""
        case (3, 2):
            return enter_optionQ3_2.text ?? ""
        case (3, 3):
            return enter_optionQ3_3.text ?? ""
        case (3, 4):
            return enter_optionQ3_4.text ?? ""
        case (4, 1):
            return enter_optionQ4_1.text ?? ""
        case (4, 2):
            return enter_optionQ4_2.text ?? ""
        case (4, 3):
            return enter_optionQ4_3.text ?? ""
        case (4, 4):
            return enter_optionQ4_4.text ?? ""
        default:
            return ""
        }
    }
    
    func getCorrectAnswer(for questionNumber: Int) -> String {
        switch questionNumber {
        case 1:
            return enter_correctq1.text ?? ""
        case 2:
            return enter_correctq2.text ?? ""
        case 3:
            return enter_correctq3.text ?? ""
        case 4:
            return enter_correctq4.text ?? ""
        default:
            return ""
        }
    }
    func createQuestionsData(completion: @escaping ([Question]) -> Void) {
        var questionsData: [Question] = []
        
        for i in 1...4 {
            let question = getQuestionText(for: i)
            let option1 = getOptionText(for: i, option: 1)
            let option2 = getOptionText(for: i, option: 2)
            let option3 = getOptionText(for: i, option: 3)
            let option4 = getOptionText(for: i, option: 4)
            let correctAnswerStr = getCorrectAnswer(for: i)
            
            if let correctAnswer = Int(correctAnswerStr) {
                let questionData = Question(questionID: i, option1: option1, option2: option2, option3: option3, option4: option4, correctAnswer: correctAnswer, question: question)
                questionsData.append(questionData)
            } else {
                print("Error: Correct answer for question \(i) is not a valid integer")
            }
        }
        
        completion(questionsData)
    }
    
    
    func getQuestionText(for questionNumber: Int) -> String {
        switch questionNumber {
        case 1:
            return enter_question1.text ?? ""
        case 2:
            return enter_question2.text ?? ""
        case 3:
            return enter_question3.text ?? ""
        case 4:
            return enter_question4.text ?? ""
        default:
            return ""
        }
    }
    
}
extension UIImage {
    func imageToBase64() -> String? {
        guard let imageData = self.pngData() else {
            return nil
        }
        return imageData.base64EncodedString()
    }
}

extension  adding_question : UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            if let imageURL = info[.imageURL] as? URL {
                let imageName = imageURL.lastPathComponent
                if let imageData = image.jpegData(compressionQuality: 1) {
                    let documentDirectory = FileManager.default.temporaryDirectory
                    let localPath = documentDirectory.appendingPathComponent(imageName)
                    convertImage = imageData
                    do {
                        try imageData.write(to: localPath)
                        upload_image.image = image
                        self.selectedImage = image
                    } catch {
                        print("Error saving image: \(error)")
                    }
                }
            }
        }
        picker.dismiss(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

extension adding_question : UITextViewDelegate {
    
}
