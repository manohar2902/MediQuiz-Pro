//
//  AddQuestionVC.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class AddQuestionVC: ViewController {

    @IBOutlet weak var text: UIView!
    
    @IBOutlet weak var proflie: UIButton!
    @IBOutlet weak var back: UIButton!
    
    @IBOutlet weak var image: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        text.layer.shadowColor = UIColor.black.cgColor
        text.layer.shadowOffset = CGSize(width: 0, height: 3)
                text.layer.shadowOpacity = 0.6
                text.layer.shadowRadius = 4
        text.layer.cornerRadius=20
        text.layer.masksToBounds = false
        
        image.layer.shadowColor = UIColor.black.cgColor
        image.layer.shadowOffset = CGSize(width: 0, height: 3)
                image.layer.shadowOpacity = 0.6
                image.layer.shadowRadius = 4
        image.layer.cornerRadius=20
        image.layer.masksToBounds = false


    }
    

    @IBAction func onback(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "DoctorHomeVC")
        as! DoctorHomeVC
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func onproflie(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ProfileVC")
        as! ProfileVC
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
}
