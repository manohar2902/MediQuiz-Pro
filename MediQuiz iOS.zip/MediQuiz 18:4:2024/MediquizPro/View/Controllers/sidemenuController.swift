//
//  sidemenuController.swift
//  s
//
//  Created by SAIL L1 on 03/01/24.
//

import UIKit

protocol SlideViewDelegate: AnyObject {
    func setAction(index:Int)
}

class sidemenuController: UIViewController{

    
    @IBOutlet weak var sideviewe: UIView!
    weak var delegate: SlideViewDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        sideviewe.layer.cornerRadius=40
        sideviewe.layer.maskedCorners = [.layerMaxXMinYCorner,.layerMaxXMaxYCorner]
        
    }
    
    @IBAction func onback(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func onprofile(_ sender: Any) {
        delegate?.setAction(index: 1)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func onleader(_ sender: Any) {
        delegate?.setAction(index: 2)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func onreview(_ sender: Any) {
        delegate?.setAction(index: 3)
        self.dismiss(animated: false, completion: nil)
    }
    @IBAction func onscore(_ sender: Any) {
        delegate?.setAction(index: 4)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func onlogout(_ sender: Any) {
        delegate?.setAction(index: 5)
        self.dismiss(animated: false, completion: nil)
    }
    
}
