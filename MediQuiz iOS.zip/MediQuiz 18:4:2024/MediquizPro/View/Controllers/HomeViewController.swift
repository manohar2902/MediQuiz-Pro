//
//  ViewController.swift
//  sampleApp
//
//  Created by SAIL on 15/09/23.
//

import UIKit
import SideMenu

class HomeViewController: UIViewController, SlideViewDelegate {
    @IBOutlet weak var instructio: UIView!
    @IBOutlet weak var sco: UIScrollView!
    @IBOutlet weak var label: UIView!
    @IBOutlet weak var topic: UIButton!
    var menu : SideMenuNavigationController?
    var pid: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        menu = SideMenuNavigationController(rootViewController: SideMenuVc())
        menu?.leftSide = true
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: (self.view))
        
        topic.layer.shadowColor = UIColor.black.cgColor
        topic.layer.shadowOffset = CGSize(width: 0, height: 3)
                topic.layer.shadowOpacity = 0.6
                topic.layer.shadowRadius = 4
        topic.layer.cornerRadius=20
        topic.layer.masksToBounds = false
        
        instructio.layer.shadowColor = UIColor.black.cgColor
        instructio.layer.shadowOffset = CGSize(width: 0, height: 3)
                instructio.layer.shadowOpacity = 0.6
                instructio.layer.shadowRadius = 4
        instructio.layer.cornerRadius=20
        instructio.layer.masksToBounds = false
    }
    @IBAction func onSideMenu() {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "sidemenuController") as! sidemenuController
        vc.delegate = self
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: false, completion: nil)
    }
    @IBAction func ontopic(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "StartViewController")
        as! StartViewController
//        if let userIDString = UserDefaults.standard.string(forKey: "userID"),let userID = Int(userIDString) {
//            vc.uid = userID
//        }
//        else {
//            print("Invalid user ID")
//        }
        self.navigationController?.pushViewController(vc, animated:true)
    }
    func setAction(index: Int) {
        switch index {
        case 0:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                    self.navigationController?.pushViewController(vc, animated: true)
        case 1:
            
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
            //let ids = viewPatient?.data[indexPath.row].id
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
            
        case 2:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "Doctorleaderboard") as! Doctorleaderboard
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 3:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "ReviewVc") as! ReviewVc
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 4:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "progressbar_2") as! progressbar_2
            //vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 5:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "InitialViewController") as! InitialViewController
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
    
        
        default:
            print("hi")
        }
    }
    
}

