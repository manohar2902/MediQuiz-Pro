//
//  SideMenuVc.swift
//  MediquizPro
//
//  Created by Saranya Ravi on 16/11/23.
//

import UIKit
struct Menu1 {
    let imagelist : UIImage?
    let namelist : String?
}
class SideMenuVc: UITableViewController {

    var menuList1 : [Menu1] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tableView.register(UINib(nibName: "sidecell", bundle: nil), forCellReuseIdentifier: "sidecell")
            tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        
        //tableView.tableHeaderView?.backgroundColor = UIColor.init(coder: <#T##NSCoder#>)
        
            menuList1.append(Menu1(imagelist: UIImage(named: "Male User"), namelist: "Profile"))
            menuList1.append(Menu1(imagelist: UIImage(named: "Laurel Wreath"), namelist: "Leader Board"))
            menuList1.append(Menu1(imagelist: UIImage(named: "10897902 1"), namelist: "Review Answer"))
            menuList1.append(Menu1(imagelist: UIImage(named: "Scorecard"), namelist: "Score"))
            menuList1.append(Menu1(imagelist: UIImage(named: "Logout Rounded Left"), namelist: "Logout"))
        tableView.reloadData()
    }
    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuList1.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sidecell", for: indexPath) as! sidecell
        let dict = menuList1[indexPath.row]
        cell.namelist.text = dict.namelist
        cell.imagelist.image = dict.imagelist
        return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "ProfileVC")
            as! ProfileVC
            self.navigationController?.pushViewController(vc, animated:true)
            
        }
        else if indexPath.row == 1 {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "leader_board")
            as! leader_board
            self.navigationController?.pushViewController(vc, animated:true)
            
        }
        else if indexPath.row == 2 {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "ReviewVc")
            as! ReviewVc
            self.navigationController?.pushViewController(vc, animated:true)
            
        }
        else if indexPath.row == 3 {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "progressbar")
            as! progressbar
            self.navigationController?.pushViewController(vc, animated:true)
            
        }
        else if indexPath.row == 4 {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "InitialViewController")
            as! InitialViewController
            self.navigationController?.pushViewController(vc, animated:true)
            
        }
        
    }
}


