

import UIKit

class ReviewVc: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var correctTable: UITableView! {
        didSet {
            correctTable.delegate = self
            correctTable.dataSource = self
        }
    }
    @IBOutlet weak var wrongTable: UITableView! {
        didSet {
            wrongTable.delegate = self
            wrongTable.dataSource = self
        }
    }
    var correctAnswerList : [MatchedAnswersArray] = []
    var wrongAnswerList : [MatchedAnswersArray] = []
    
    var pid: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        correctTable.register(UINib(nibName: "CheckAnswerCell", bundle: nil), forCellReuseIdentifier: "cell")
        wrongTable.register(UINib(nibName: "CheckAnswerCell", bundle: nil), forCellReuseIdentifier: "cell")
        wrongTable.isHidden = true
        correctTable.isHidden = false
        correctAPI(user_id: UserDefaults.standard.string(forKey: "userID") ?? "")
        wrongAnsAPI(user_id: UserDefaults.standard.string(forKey: "userID") ?? "")
        loadTableData()
    }
    func loadTableData() {
        correctTable.reloadData()
        wrongTable.reloadData()
    }
    func correctAPI(user_id:String){
        let formData:[String:String] = [
            "user_id":user_id
        ]
        APIHandler().postAPIValues(type: Correctanswer.self, apiUrl: ServiceAPI.correctAnswer, method: "POST", formData: formData){ result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.correctAnswerList = data.matchedAnswersArray
                    self.loadTableData()
                }
            case .failure(let error):
                print(error)

            }
        }
    }
    func wrongAnsAPI(user_id:String) {
        let formData:[String:String] = [
            "user_id":user_id
        ]
        APIHandler().postAPIValues(type: Wronganswer.self, apiUrl: ServiceAPI.wrongAnswer, method: "POST", formData: formData){ result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.wrongAnswerList = data.unmatchedAnswersArray
                    self.loadTableData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    @IBAction func onSegment(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            correctTable.isHidden = false
            wrongTable.isHidden = true
        }
        else if sender.selectedSegmentIndex == 1{
            correctTable.isHidden = true
            wrongTable.isHidden = false
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == correctTable {
            print("Correct count",correctAnswerList.count)
            return correctAnswerList.count
            
        }
        else if tableView == wrongTable {
            print("Wrong count",wrongAnswerList.count)
            return wrongAnswerList.count
        }
       return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CheckAnswerCell
        if tableView == correctTable {
            let dict = correctAnswerList[indexPath.row]
            cell.caseStudyView.text = dict.caseStudy
            cell.questionLbl.text = dict.question
            cell.answerLbl.text = dict.matchedOption
            cell.userAnswer.isHidden = true
            cell.rightOrwrongAnsLbl.textColor = UIColor.systemGreen
            cell.rightOrwrongAnsLbl.text = "Correct"
            
        }
        else if tableView == wrongTable {
            let dict = wrongAnswerList[indexPath.row]
            cell.caseStudyView.text = dict.caseStudy
            cell.questionLbl.text = dict.question
            cell.answerLbl.text = "Correct Answer: "+dict.matchedOption
            cell.userAnswer.isHidden = false
            cell.userAnswer.text = "User Answer: " + dict.userAnswer ?? ""
            cell.rightOrwrongAnsLbl.textColor = UIColor.red
            cell.rightOrwrongAnsLbl.text = "Wrong"
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180.0
    }
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
