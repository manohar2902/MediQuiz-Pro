//
//  QuestionHistoryVC.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class QuestionHistoryVC: ViewController {

    @IBOutlet weak var back: UIButton!
    @IBOutlet weak var questionTable : UITableView!
    @IBOutlet weak var proflie: UIButton!
    
    
    var index = 0
    var questionDetails: HistoryQuestionsModel?
    
    var quesArray : [String] = ["An abormal narrowing in a blood vessel or other tubular organ or structure"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        questionDetails = HistoryQuestionsModel()
        let cell = UINib(nibName: "CaseStudyCell", bundle: nil)
        questionTable.register(cell, forCellReuseIdentifier: "Cell")
        
        self.questionTable.delegate = self
        self.questionTable.dataSource = self
        questionAPI()
    }
   
    
    func questionAPI() {
        LoadingIndicator.shared.showLoading(on: view)
        APIHandler().getAPIValues(type: HistoryQuestionsModel.self, apiUrl: "http://172.20.10.8/manohariOS/questions.php", method: "GET") { [self] Result in
            print("RESULT---->",Result)
            switch Result {
            case .success(let data):
              
                self.questionDetails?.historyQuestions = data.historyQuestions
                LoadingIndicator.shared.hideLoading()
                
                DispatchQueue.main.async {
                    
                    
                    self.questionTable.reloadData()
                }
                print(data)
                
            case .failure(let error):
                LoadingIndicator.shared.hideLoading()
                print("Error Type",error)
            }
        }
    }
    

    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onproflie(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ProfileVC")
        as! ProfileVC
        self.navigationController?.pushViewController(vc, animated:true)
        index = 1
        questionTable.reloadData()
    }
}


extension QuestionHistoryVC: UITableViewDelegate, UITableViewDataSource {
    
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return 2
//    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return questionDetails?.historyQuestions.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! CaseStudyCell
      
        cell.caseLbl.text = questionDetails?.historyQuestions[indexPath.row].caseStudy
        cell.questionModel = questionDetails?.historyQuestions[indexPath.row].subQuestions ?? []
        if let imgUrlString = questionDetails?.historyQuestions[indexPath.row].photo, let imgUrl = URL(string: imgUrlString), let data = try? Data(contentsOf: imgUrl)  {
            cell.photo.image = UIImage(data: data)
          
        }
       
        return cell
    }


    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

}
