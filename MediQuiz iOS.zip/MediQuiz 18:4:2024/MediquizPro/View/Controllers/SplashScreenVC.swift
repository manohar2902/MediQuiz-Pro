//
//  SplashScreenVC.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import UIKit
class SplashScreenVC: ViewController {
    var timer : Timer!
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(moveLogin), userInfo: nil, repeats: false)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = true
        
    }
    @objc func moveLogin() {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "InitialViewController") as! InitialViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
