import UIKit

class StartViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func onStart(_ sender: Any) {
        // Retrieve user ID from UserDefaults
        guard let userId = UserDefaults.standard.string(forKey: "userID") else {
            print("User ID not found in UserDefaults")
            return
        }
        let formData : [String : String] = ["user_id" : userId]
        APIHandler().postAPIValues(type: TestStatusResponse.self, apiUrl: ServiceAPI.checking, method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let response):
                if response.status == 0 {
                    DispatchQueue.main.async {
                        self.navigateToNextViewController()
                    }
                }
                else if response.status == 1 {
                    DispatchQueue.main.async {
                        self.showTestTakenAlert()
                    }
                }
                else {
                    print("Unknown response status")
                }
            case .failure(let error):
                print("API request failed with error : \(error)")
                DispatchQueue.main.async {
                    self.navigateToNextViewController()
                }
            }
        }
    }
    func showTestTakenAlert() {
        let alert = UIAlertController(title: "Test Already Taken", message: "You have already taken the test", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }
    func navigateToNextViewController() {
        // Perform navigation to the next view controller
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let nextViewController = storyboard.instantiateViewController(withIdentifier: "QuestionVC") as? QuestionVC {
            DispatchQueue.main.async {
                nextViewController.uid = Int(UserDefaults.standard.string(forKey: "userID")!)
                self.navigationController?.pushViewController(nextViewController, animated: true)
            }
        }
    }
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)

    }
    
}

