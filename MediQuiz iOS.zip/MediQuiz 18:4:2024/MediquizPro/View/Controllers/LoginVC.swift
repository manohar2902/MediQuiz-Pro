

import UIKit

class LoginVC: BasicViewController {
    var logInDetails : LoginModel!
    @IBOutlet weak var enter_password: UITextField!
    @IBOutlet weak var enter_user_id: UITextField!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var signup: UIButton!
    @IBOutlet weak var onview: UIView!
    
    @IBOutlet weak var showpassword: UIButton!
    let loaderView = loader()
    var isPasswordVisible = false
    override func viewDidLoad() {
        super.viewDidLoad()
        updatePasswordVisibility()
        onview.addSubview(loaderView)
                        loaderView.translatesAutoresizingMaskIntoConstraints = false
                        NSLayoutConstraint.activate([
                            loaderView.centerXAnchor.constraint(equalTo: onview.centerXAnchor),
                            loaderView.centerYAnchor.constraint(equalTo: onview.centerYAnchor)
                        ])


        setupTapGestureToDismissKeyboard()
    }
    
    
    @IBAction func onshow(_ sender: Any) {
        isPasswordVisible = !isPasswordVisible
                updatePasswordVisibility()
    }
    
    func updatePasswordVisibility() {
            if isPasswordVisible {
                // Show password
                enter_password.isSecureTextEntry = false
                showpassword.setTitle("", for: .normal)
            } else {
                // Hide password
                enter_password.isSecureTextEntry = true
                showpassword.setTitle("", for: .normal)
            }
        }
    @IBAction func onlogin(_ sender: Any) {
        showLoader()
                if enter_user_id.text?.isEmpty == true {
                    showToast("Enter the UserName")
                    hideLoader()
                } else if enter_password.text?.isEmpty == true {
                    showToast("Enter the Password")
                    hideLoader()
                } else {
                    GetAPI()
                }
            }
    
    
    @IBAction func omsignup(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "SignInVC")
        as! SignInVC
        self.navigationController?.pushViewController(vc, animated:true)
        
    }
    
    @IBAction func onforgot(_ sender: Any){
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ForgotPasswordVC")
        as! ForgotPasswordVC
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func onback(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    func showLoader(){
        loaderView.startAnimating()
    }
    func hideLoader(){
        loaderView.stopAnimating()
    }
    
}
extension LoginVC {

        func GetAPI() {
            let apiurl = APIHandler().getAPIValues(type: LoginModel.self, apiUrl: "\(ServiceAPI.baseUrl)manohariOS/login.php?user_id=\(enter_user_id.text ?? "")&password=\(enter_password.text ?? "")", method: "GET") { [self] Result in
                switch Result {
                case .success(let data):
                    self.logInDetails = data
                    print(data)
                    DispatchQueue.main.async { [self] in
                        UserDefaults.standard.set(enter_user_id.text ?? "", forKey: "userID")
                        if logInDetails.data.designation == "Doctor" {
                            let alertController = UIAlertController(title: "Student Login", message: "Use Student Id to Login.", preferredStyle: .alert)
                            
                            // Add an action button to dismiss the alert
                            let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
                                // Navigate to the old page
                                if let navigationController = self.navigationController {
                                    navigationController.popViewController(animated: true)
                                } else {
                                    // Handle case when navigationController is nil
                                    print("Navigation Controller is nil")
                                }
                            }
                            alertController.addAction(okAction)
                            
                            // Present the alert
                            self.present(alertController, animated: true, completion: nil)
                        } else if logInDetails.data.designation == "Student" {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        } else if self.logInDetails.status == false {
                            DispatchQueue.main.async {
                                print(self.logInDetails.message)
                                showToast(self.logInDetails.message ?? " " )
                            }
                        }
                        hideLoader()
                    }
 
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                            print("JSON Error")
                        })
                        self.present(alert, animated: true, completion: nil)
                        hideLoader()
                    }
                }
            }
        }
    
    func setupTapGestureToDismissKeyboard() {
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
            tapGesture.cancelsTouchesInView = false // Allow other gesture recognizers to work alongside this one
            view.addGestureRecognizer(tapGesture)
        }
        
        @objc func dismissKeyboard() {
            view.endEditing(true)
        }

    }
