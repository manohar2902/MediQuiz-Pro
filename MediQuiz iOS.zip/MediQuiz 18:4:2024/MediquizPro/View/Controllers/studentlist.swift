//
//  studentlist.swift
//  MediquizPro
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class studentlist: UIViewController {
    
    
    
   
    @IBOutlet weak var back: UIButton!
    

    @IBOutlet weak var studentlist: UITableView!
    
    
    
    var namelist = ["Student1","Student2","Student3"]
    var numberlist = ["47/50","46/50","44/50"]
    
    
    var studentListDetail = [WelcomeElement]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
 
       
        studentlist.delegate = self
        studentlist.dataSource = self
        studentlist.register(UINib(nibName: "student_list", bundle: nil), forCellReuseIdentifier: "student_list")
        
        
        GetAPI()

    }
    func GetAPI() {
        
        
     let apiurl = APIHandler().getAPIValues(type: studentlistmodel.self, apiUrl: "http://172.20.10.8/manohariOS/studentlist.php", method: "GET") { [self] Result in
            switch Result {
               
            case .success(let data):
                studentListDetail = data
                DispatchQueue.main.async {
                    studentlist.reloadData()
                }
                
//                DispatchQueue.main.async {
//                    if logInDetails.data.userType == "Doctor"{
//                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorHomeVC")
//                       as! DoctorHomeVC
//                    self.navigationController?.pushViewController(vc, animated: true)
//                   }
//                    else if logInDetails.data.userType  == "Student"{
//                   let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
//                   self.navigationController?.pushViewController(vc, animated: true)
//
//
//
//                   }
//                   else if self.logInDetails.status == false{
//                       DispatchQueue.main.async {
//                           print(self.logInDetails.message)
//                           showToast(self.logInDetails.message ?? " " )
//                       }
//                   }
//                }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
            
    }
}
    
   
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
        
    }
  
    }
extension studentlist: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentListDetail.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "student_list", for: indexPath) as! student_list
        cell.name.text = studentListDetail[indexPath.row].userID
        cell.marks.text = studentListDetail[indexPath.row].totalScore
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
    
}
