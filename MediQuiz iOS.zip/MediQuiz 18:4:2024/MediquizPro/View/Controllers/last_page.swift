//
//  last_page.swift
//  MediquizPro
//
//  Created by SAIL on 12/10/23.
//

import UIKit

class last_page: UIViewController {

    @IBOutlet weak var `continue`: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

    @IBAction func oncontinue(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "HomeViewController")
        as! HomeViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    

}
