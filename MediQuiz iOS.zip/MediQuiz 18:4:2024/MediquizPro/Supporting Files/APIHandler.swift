import Foundation
import UIKit


class APIHandler {
    static var shared: APIHandler = APIHandler()
    
    init() {}
    var dynamicId = ""
    
    func getAPIValues<T:Codable>(type: T.Type, apiUrl: String, method: String, onCompletion: @escaping (Result<T, Error>) -> Void) {
                
        guard let url = URL(string: apiUrl) else {
                    let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
                    onCompletion(.failure(error))
                    return
                }
                
                var request = URLRequest(url: url)
                request.httpMethod = "GET"
                                
                let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                    if let error = error {
                        onCompletion(.failure(error))
                        return
                    }
                    
                    guard let data = data else {
                        let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                        onCompletion(.failure(error))
                        return
                    }
                    
                    do {
                        let decodedData = try JSONDecoder().decode(type, from: data)
                        onCompletion(.success(decodedData))
                        print(decodedData)
                    } catch {
                        onCompletion(.failure(error))
                    }
                }
                
                task.resume()
    }
    
    func postAPIValues<T: Codable>(
        type: T.Type,
        apiUrl: String,
        method: String,
        formData: [String: Any], // Dictionary for form data parameters
        onCompletion: @escaping (Result<T, Error>) -> Void
    ) {
        guard let url = URL(string: apiUrl) else {
            let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
            onCompletion(.failure(error))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Construct the form data string
        var formDataString = ""
        for (key, value) in formData {
            formDataString += "\(key)=\(value)&"
        }
        formDataString = String(formDataString.dropLast()) // Remove the trailing "&"
        
        // Set the request body
        request.httpBody = formDataString.data(using: .utf8)
        
        // Set the content type to "application/x-www-form-urlencoded"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                onCompletion(.failure(error))
                return
            }
            
            guard let data = data else {
                let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                onCompletion(.failure(error))
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode(type, from: data)
                onCompletion(.success(decodedData))
                print(decodedData)
            } catch {
                onCompletion(.failure(error))
            }
        }
        
        task.resume()
    }

        
    func postAPIRawJSON<T: Codable>(
        type: T.Type,
        apiUrl: String,
        method: String,
        jsonData: Data,
        onCompletion: @escaping (Result<T, Error>) -> Void
    ) {
        guard let url = URL(string: apiUrl) else {
            let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
            onCompletion(.failure(error))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                onCompletion(.failure(error))
                return
            }
            
            guard let data = data else {
                let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                onCompletion(.failure(error))
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode(type, from: data)
                onCompletion(.success(decodedData))
                print("------APIHAndler",decodedData, "decodedData------")
            } catch {
                onCompletion(.failure(error))
            }
        }
        task.resume()
    }
    
    func postMethodWithFormData(url: URL,formData: [String:Any],onCompletion: @escaping (Result< Any, Error>) -> Void) {
        // Create the request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let boundary = UUID().uuidString
        // Convert the form data dictionary into Datalet boundary = UUID().uuidString
        
      

        // Set the request body
       // request.httpBody = body

        // Set the content type header
        let contentType = "multipart/form-data; boundary=\(boundary)"
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")

        // Create a URLSessionDataTask and send the request
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            // Handle response
            if let error = error {
                print("Error: \(error)")
                return
            }
            
            // Handle data
            if let data = data {
                if let responseString = String(data: data, encoding: .utf8) {
                    print("Response: \(responseString)")
                }
            }
        }

        task.resume()
    }
    
    func createMultipartFormData(parameters: [String: Any], boundary: String) -> Data {
        var body = Data()

        for (key, value) in parameters {
            if let image = value as? UIImage, let imageData = image.jpegData(compressionQuality: 1.0) {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"\(key)\"; filename=\"\(dynamicId).jpg\"\r\n".data(using: .utf8)!)
                body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
                body.append(imageData)
                body.append("\r\n".data(using: .utf8)!)
            } else if let stringValue = value as? String {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
                body.append(stringValue.data(using: .utf8)!)
                body.append("\r\n".data(using: .utf8)!)
            }
        }

        body.append("--\(boundary)--\r\n".data(using: .utf8)!) // Ending boundary

        return body
    }

    func PostUIImageToAPI(apiUrl: URL, id: String, requestBody: [String:Any], onCompletion: @escaping (Result<Any, Error>) -> Void) {
        let boundary = UUID().uuidString
        dynamicId = id

        var request = URLRequest(url: apiUrl)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        // Create the request body using the provided parameters
        let body = createMultipartFormData(parameters: requestBody, boundary: boundary)
        if let bodyString = String(data: body, encoding: .utf8) {
            print("Request Body:")
            print(bodyString)
        } else {
            print("Failed to convert body to string")
        }
        request.httpBody = body

        // Create URLSessionDataTask for making the request
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            // Check for any errors
            if let error = error {
                onCompletion(.failure(error))
                return
            }

            // Check if there's any data returned
            guard let data = data else {
                onCompletion(.failure(NSError(domain: "com.example", code: -1, userInfo: [NSLocalizedDescriptionKey: "No data returned from POST request"])))
                return
            }


            if let httpResponse = response as? HTTPURLResponse {
                print("Status Code: \(httpResponse.statusCode)")
                print("Response Data:")
                print(String(data: data, encoding: .utf8) ?? "Failed to decode response data")
                do {
                    let jsonResponse = try JSONSerialization.jsonObject(with: data, options: [])
                    onCompletion(.success(jsonResponse))
                } catch {
                    onCompletion(.failure(error))
                }
            }
        }

        task.resume()
    }

    func postMultipartAPI<T: Codable>(apiURL: String, formData: [String: Any], fieldNames: [String], selectedImages: [UIImage], responseType: T.Type, completion: @escaping (Result<T, Error>) -> Void) {
        guard let url = URL(string: apiURL) else {
            let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
            completion(.failure(error))
            return
        }
        
        let boundary = UUID().uuidString
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = Data()
        
        // Add form data parameters
        for (key, value) in formData {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }
        
        // Add image data
        for (index, image) in selectedImages.enumerated() {
            guard index < fieldNames.count else {
                break
            }
            let fieldName = fieldNames[index]
            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
            body.append(imageData)
            body.append("\r\n".data(using: .utf8)!)
        }
        
        // Add closing boundary
        body.append("--\(boundary)--\r\n".data(using: .utf8)!) // Close the request body
        
        request.httpBody = body
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                completion(.failure(error))
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode(responseType, from: data)
                completion(.success(decodedData))
            } catch {
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
}
