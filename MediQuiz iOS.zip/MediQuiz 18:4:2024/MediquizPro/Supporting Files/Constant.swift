
import Foundation
import UIKit


struct ServiceAPI {
    static let baseUrl = "http://172.20.10.8/" ///
    ///
    ///
    ///
    static let signupUrl = baseUrl+"manohariOS/signup.php?"
    static let loginURL = baseUrl+"/manohariOS/login.php?"
    static let scoreboardURL = baseUrl+"ios/scoreboard1.php?"
    static let overallscoreboardURL = baseUrl+"ios/overallscoreboard.php?"
    static let profileAPI = baseUrl+"/manohariOS/profile.php"
    static let achievementURL = baseUrl+"ios/achievements.php"
    static let editprofileURL = baseUrl+"manohariOS/editprofile.php"
    static let getQuestion = baseUrl+"/manohariOS/getquestions.php"
    static let insertAnswer = baseUrl+"/manohariOS/insetanswer.php"
    static let correctAnswer = baseUrl+"/manohariOS/correctanswers.php"
    static let wrongAnswer = baseUrl+"/manohariOS/wronganswers.php"
    
    
    static let checking = baseUrl+"manohariOS/checking.php"
    
    static let scoreurl = baseUrl+"/manohariOS/showscore.php"
    static let totalScore = baseUrl+"/manohariOS/totalscore.php"
    static let casestudyCount = baseUrl+"/manohariOS/count.php"
    static let addCaseStudy = baseUrl+"manohariOS/insert_casestudy.php"
    static let addQuestions = baseUrl+"/manohariOS/insert_subquestions.php"
   
    
    static let showphoto = baseUrl+"/manohariOS/show_photo.php"
    static let insetQuestions = baseUrl+"/manohariOS/insetquestions.php"

}
