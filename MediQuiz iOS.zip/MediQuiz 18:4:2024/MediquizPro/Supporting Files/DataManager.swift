//
//  DataManager.swift
//  MediquizPro
//
//  Created by SAIL L1 on 29/12/23.
//

import Foundation


class DataManager {
    static let shared = DataManager()

  
  
        var firstQueAns:String?
        var secondQueAns:String?
        var thirdQueAns:String?
        var fourthQueAns:String?
   

   

     init() {}
}
